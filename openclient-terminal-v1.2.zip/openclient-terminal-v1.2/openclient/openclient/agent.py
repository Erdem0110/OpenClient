"""Ajan döngüsü: model → araç çağrıları → izin → sonuç → model ..."""

from __future__ import annotations

import datetime
import os
import platform
import time
from pathlib import Path

from . import tools, ui
from .providers import ProviderError, Turn

MAX_STEPS = 60

BASE_PROMPT = """You are OpenClient, an interactive terminal coding agent. You help the user with software \
engineering tasks (fixing bugs, adding features, refactoring, explaining code, running commands) \
by using the tools available to you.

# How to work
- Be concise and direct: your output is shown in a terminal. Avoid preamble and avoid repeating what tools already showed.
- Reply in the same language the user writes in.
- Explore before you change things: use ls/glob/grep/read to understand the code and follow its existing conventions.
- Prefer `edit` for changes to existing files and `write` only for new files. Always read a file before editing it.
- Make the smallest change that solves the task. Do not add comments, files or refactors nobody asked for.
- After changing code, verify it when practical (run tests, linters, or the program) with `bash`.
- Never run destructive commands (rm -rf, git reset --hard, force pushes ...) unless the user asked for it.
- When referencing code, use the form `path/to/file.py:42`.
- If a request is ambiguous in a way that matters, ask one short question instead of guessing.
"""

PLAN_PROMPT = """
# PLAN MODE
You are in read-only plan mode. You may read, search and fetch, but you must NOT modify files or run \
shell commands (those tools are disabled). Analyse the task and produce a clear, step-by-step plan \
that the user can approve; mention the exact files and functions you would change.
"""


def load_project_rules(cwd: Path) -> str:
    names = ("AGENTS.md", "CLAUDE.md")
    home = Path.home()
    for d in [cwd, *cwd.parents]:
        for n in names:
            f = d / n
            if f.is_file():
                try:
                    return f"\n# Project rules ({f})\n" + f.read_text(encoding="utf-8")[:20000]
                except OSError:
                    pass
        if d == home:
            break
    return ""


class Agent:
    def __init__(self, provider, spec: dict, cwd: Path, auto_approve: bool = False,
                 interactive: bool = True) -> None:
        self.provider = provider
        self.spec = spec
        self.cwd = cwd
        self.auto_approve = auto_approve
        self.interactive = interactive
        self.mode = "build"
        self.history: list[dict] = []
        self.always: set[str] = set()
        self.last_usage = (0, 0)
        self._asked = False

    # -- sistem istemi ------------------------------------------------------
    def system_prompt(self) -> str:
        env = (f"\n# Environment\n- Working directory: {self.cwd}\n- Platform: {platform.system()} "
               f"({os.name})\n- Date: {datetime.date.today().isoformat()}\n- Shell: "
               f"{'cmd/PowerShell' if os.name == 'nt' else os.environ.get('SHELL', 'sh')}\n")
        return BASE_PROMPT + (PLAN_PROMPT if self.mode == "plan" else "") + env + load_project_rules(self.cwd)

    def set_provider(self, provider, spec: dict) -> None:
        self.provider, self.spec = provider, spec

    # -- izin ---------------------------------------------------------------
    def _preview(self, name: str, args: dict) -> None:
        if name == "edit":
            old = "\n".join("-" + ln for ln in str(args.get("old_string", "")).splitlines())
            new = "\n".join("+" + ln for ln in str(args.get("new_string", "")).splitlines())
            ui.print_diff(f"--- {args.get('path', '')}\n{old}\n{new}")
        elif name == "write":
            body = str(args.get("content", "")).splitlines()
            ui.tool_output("\n".join(body[:6]) + (f"\n… {len(body)} satır" if len(body) > 6 else ""), 7)

    def _allowed(self, tool: tools.Tool, args: dict) -> bool:
        if tool.readonly or self.auto_approve or tool.name in self.always:
            return True
        self._preview(tool.name, args)
        self._asked = True
        if not self.interactive:
            return False
        choice = ui.ask_permission(tool.name, tool.summary(args))
        if choice == "always":
            self.always.add(tool.name)
        return choice != "deny"

    # -- ana döngü ----------------------------------------------------------
    def run(self, user_text: str) -> None:
        self.history.append({"role": "user", "content": user_text})
        t0 = time.time()
        tin = tout = 0
        for _ in range(MAX_STEPS):
            spinner = ui.Spinner()
            md = ui.MarkdownStream(on_first_output=spinner.stop)
            spinner.start()
            try:
                turn: Turn = self.provider.stream(self.history, self.system_prompt(),
                                                  tools.specs(self.mode == "plan"), md.feed)
            except KeyboardInterrupt:
                spinner.stop()
                md.finish()
                ui.warn("Yanıt durduruldu.")
                return
            except ProviderError as e:
                spinner.stop()
                md.finish()
                ui.error(str(e))
                self._drop_dangling_user()
                return
            except Exception as e:  # ağ kopması vb.
                spinner.stop()
                md.finish()
                ui.error(f"Beklenmeyen hata: {type(e).__name__}: {e}")
                self._drop_dangling_user()
                return
            spinner.stop()
            md.finish()
            tin += turn.tokens_in
            tout += turn.tokens_out

            self.history.append({"role": "assistant", "content": turn.text, "tool_calls": turn.tool_calls})
            if not turn.tool_calls:
                break
            if not self._run_tools(turn.tool_calls):
                break
            if turn.stop_reason == "max_tokens":
                ui.warn("Yanıt token sınırına takıldı.")
        else:
            ui.warn(f"{MAX_STEPS} adım sınırına ulaşıldı; devam etmek için bir şey yaz.")
        self.last_usage = (tin, tout)
        ui.footer(self.mode, self.spec["model"], time.time() - t0, tin, tout)

    def _drop_dangling_user(self) -> None:
        # hata olduysa son kullanıcı mesajı yanıtsız kalmasın diye geri al
        if self.history and self.history[-1]["role"] == "user":
            self.history.pop()

    def _run_tools(self, calls: list[dict]) -> bool:
        """Araçları çalıştırır. Kesilirse False döner (tüm çağrılar yine de yanıtlanır)."""
        done: set[str] = set()
        try:
            for call in calls:
                self._exec(call)
                done.add(call["id"])
            return True
        except KeyboardInterrupt:
            ui.warn("Durduruldu.")
            return False
        finally:
            answered = {m.get("tool_call_id") for m in self.history[-len(calls) - 1:] if m["role"] == "tool"}
            for call in calls:
                if call["id"] not in done and call["id"] not in answered:
                    self.history.append({"role": "tool", "tool_call_id": call["id"], "name": call["name"],
                                         "content": "Kullanıcı tarafından durduruldu.", "is_error": True})

    def _exec(self, call: dict) -> None:
        name, args = call["name"], call["args"]
        self._asked = False
        tool = tools.BY_NAME.get(name)
        result: tools.ToolResult
        if tool is None:
            result = tools.ToolResult(f"Bilinmeyen araç: {name}", True)
            ui.tool_header(name, "", "error")
        elif "_invalid_json" in args:
            result = tools.ToolResult("Araç argümanları geçerli JSON değil, tekrar dene.", True)
            ui.tool_header(name, "geçersiz argüman", "error")
        elif self.mode == "plan" and not tool.readonly:
            result = tools.ToolResult("Plan modunda bu araç kapalı. Kullanıcı /build ile moda geçmeli.", True)
            ui.tool_header(name, tool.summary(args), "error")
        else:
            ui.tool_header(name, tool.summary(args))
            if not self._allowed(tool, args):
                result = tools.ToolResult("Kullanıcı bu işlemi reddetti.", True)
                ui.out(ui.style("  │ ", "border") + ui.style("reddedildi", "error"))
            else:
                try:
                    result = tool.run(args, self.cwd)
                except KeyboardInterrupt:
                    raise
                except Exception as e:
                    result = tools.ToolResult(f"Araç hatası: {type(e).__name__}: {e}", True)
                if result.diff and not (self._asked and not result.is_error):
                    ui.print_diff(result.diff)
                elif result.diff:
                    ui.out(ui.style("  │ ", "border") + ui.style(result.output, "success"))
                elif tool.name in ("bash", "grep", "glob", "webfetch") or result.is_error:
                    ui.tool_output(result.output, 8, result.is_error)
                elif tool.name == "read":
                    ui.out(ui.style("  │ ", "border") + ui.style(
                        f"{len(result.output.splitlines())} satır", "muted"))
        self.history.append({"role": "tool", "tool_call_id": call["id"], "name": name,
                             "content": tools._truncate(result.output), "is_error": result.is_error})

    # -- yardımcılar --------------------------------------------------------
    def compact(self) -> bool:
        if len(self.history) < 4:
            ui.info("Sıkıştırılacak kadar konuşma yok.")
            return False
        msgs = self.history + [{"role": "user", "content": (
            "Summarize our conversation so far so work can continue in a fresh context: goals, decisions, "
            "files touched, current state and next steps. Be compact but complete.")}]
        buf: list[str] = []
        spinner = ui.Spinner("Özetleniyor")
        spinner.start()
        try:
            turn = self.provider.stream(msgs, self.system_prompt(), [], buf.append)
        except (ProviderError, KeyboardInterrupt) as e:
            spinner.stop()
            ui.error(str(e) or "durduruldu")
            return False
        spinner.stop()
        self.history = [
            {"role": "user", "content": "Önceki konuşmanın özeti:\n\n" + turn.text},
            {"role": "assistant", "content": "Özeti aldım, devam edebiliriz.", "tool_calls": []},
        ]
        ui.info(f"Bağlam sıkıştırıldı ({turn.tokens_out:,} token özet).")
        return True
