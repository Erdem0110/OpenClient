"""Test için sahte OpenAI-uyumlu ve Anthropic sunucusu (SSE akışı)."""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

REQUESTS: list[dict] = []


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # sessiz
        pass

    def _sse(self, events: list[tuple[str | None, dict | str]]) -> None:
        self.send_response(200)
        self.send_header("content-type", "text/event-stream")
        self.end_headers()
        for ev, data in events:
            if ev:
                self.wfile.write(f"event: {ev}\n".encode())
            payload = data if isinstance(data, str) else json.dumps(data)
            self.wfile.write(f"data: {payload}\n\n".encode())
            self.wfile.flush()

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["content-length"])))
        REQUESTS.append({"path": self.path, "body": body, "headers": {k.lower(): v for k, v in self.headers.items()}})
        if self.path.endswith("/chat/completions"):
            self._openai(body)
        elif self.path.endswith("/v1/messages"):
            self._anthropic(body)
        else:
            self.send_response(404)
            self.end_headers()

    # -- OpenAI -------------------------------------------------------------
    def _openai(self, body):
        has_tool_result = any(m["role"] == "tool" for m in body["messages"])
        if body["model"] == "bad":
            self.send_response(401)
            self.end_headers()
            self.wfile.write(json.dumps({"error": {"message": "Incorrect API key"}}).encode())
            return
        if not has_tool_result:
            args = json.dumps({"path": "hello.txt", "content": "merhaba\ndünya\n"})
            ev = [(None, {"choices": [{"delta": {"content": "Dosyayı yazıyorum.\n"}}]}),
                  (None, {"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "call_1",
                          "function": {"name": "write", "arguments": args[:15]}}]}}]}),
                  (None, {"choices": [{"delta": {"tool_calls": [{"index": 0,
                          "function": {"arguments": args[15:]}}]}, "finish_reason": "tool_calls"}]}),
                  (None, {"choices": [], "usage": {"prompt_tokens": 100, "completion_tokens": 20}}),
                  (None, "[DONE]")]
        else:
            text = "Bitti! `hello.txt` oluşturuldu.\n\n- **kalın** madde\n\n```python\nprint('x')\n```\n"
            ev = [(None, {"choices": [{"delta": {"content": text[:12]}}]}),
                  (None, {"choices": [{"delta": {"content": text[12:]}, "finish_reason": "stop"}]}),
                  (None, {"choices": [], "usage": {"prompt_tokens": 150, "completion_tokens": 30}}),
                  (None, "[DONE]")]
        self._sse(ev)

    # -- Anthropic ----------------------------------------------------------
    def _anthropic(self, body):
        has_tool_result = any(
            isinstance(m["content"], list) and any(b.get("type") == "tool_result" for b in m["content"])
            for m in body["messages"])
        if not has_tool_result:
            args = json.dumps({"command": "echo selam"})
            ev = [("message_start", {"type": "message_start", "message": {"usage": {"input_tokens": 80}}}),
                  ("content_block_start", {"type": "content_block_start", "index": 0,
                                           "content_block": {"type": "text", "text": ""}}),
                  ("content_block_delta", {"type": "content_block_delta", "index": 0,
                                           "delta": {"type": "text_delta", "text": "Çalıştırıyorum\n"}}),
                  ("content_block_stop", {"type": "content_block_stop", "index": 0}),
                  ("content_block_start", {"type": "content_block_start", "index": 1,
                                           "content_block": {"type": "tool_use", "id": "toolu_1", "name": "bash"}}),
                  ("content_block_delta", {"type": "content_block_delta", "index": 1,
                                           "delta": {"type": "input_json_delta", "partial_json": args[:10]}}),
                  ("content_block_delta", {"type": "content_block_delta", "index": 1,
                                           "delta": {"type": "input_json_delta", "partial_json": args[10:]}}),
                  ("content_block_stop", {"type": "content_block_stop", "index": 1}),
                  ("message_delta", {"type": "message_delta", "delta": {"stop_reason": "tool_use"},
                                     "usage": {"output_tokens": 15}})]
        else:
            ev = [("message_start", {"type": "message_start", "message": {"usage": {"input_tokens": 120}}}),
                  ("content_block_start", {"type": "content_block_start", "index": 0,
                                           "content_block": {"type": "text", "text": ""}}),
                  ("content_block_delta", {"type": "content_block_delta", "index": 0,
                                           "delta": {"type": "text_delta", "text": "Komut çıktısı: selam"}}),
                  ("content_block_stop", {"type": "content_block_stop", "index": 0}),
                  ("message_delta", {"type": "message_delta", "delta": {"stop_reason": "end_turn"},
                                     "usage": {"output_tokens": 9}})]
        self._sse(ev)


def start() -> tuple[ThreadingHTTPServer, str]:
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}"
