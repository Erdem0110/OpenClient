import io
import json
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

# proxy ortam değişkenleri 127.0.0.1'e gitmesin
os.environ["NO_PROXY"] = os.environ["no_proxy"] = "127.0.0.1,localhost"

import mock_server  # noqa: E402
from openclient import tools, ui  # noqa: E402
from openclient.agent import Agent  # noqa: E402
from openclient.providers import Anthropic, OpenAICompat, ProviderError  # noqa: E402

ui.init_color(False)


class ToolTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cwd = Path(self.tmp.name)
        (self.cwd / "src").mkdir()
        (self.cwd / "src" / "a.py").write_text("def foo():\n    return 1\n\n# TODO: fix\n")
        (self.cwd / "src" / "b.txt").write_text("hello\n")
        (self.cwd / "node_modules").mkdir()
        (self.cwd / "node_modules" / "x.py").write_text("TODO\n")

    def tearDown(self):
        self.tmp.cleanup()

    def run_tool(self, name, **args):
        return tools.BY_NAME[name].run(args, self.cwd)

    def test_read_numbers_lines(self):
        r = self.run_tool("read", path="src/a.py")
        self.assertIn("     1\tdef foo():", r.output)
        self.assertFalse(r.is_error)

    def test_read_missing(self):
        self.assertTrue(self.run_tool("read", path="yok.py").is_error)

    def test_write_and_edit(self):
        r = self.run_tool("write", path="new/dir/f.txt", content="a\nb\n")
        self.assertIn("oluşturuldu", r.output)
        self.assertTrue((self.cwd / "new/dir/f.txt").exists())
        r = self.run_tool("edit", path="new/dir/f.txt", old_string="b", new_string="c")
        self.assertFalse(r.is_error)
        self.assertEqual((self.cwd / "new/dir/f.txt").read_text(), "a\nc\n")
        self.assertIn("+c", r.diff)

    def test_edit_ambiguous_and_missing(self):
        (self.cwd / "d.txt").write_text("x x")
        self.assertTrue(self.run_tool("edit", path="d.txt", old_string="x", new_string="y").is_error)
        self.assertFalse(self.run_tool("edit", path="d.txt", old_string="x", new_string="y", replace_all=True).is_error)
        self.assertEqual((self.cwd / "d.txt").read_text(), "y y")
        self.assertTrue(self.run_tool("edit", path="d.txt", old_string="zzz", new_string="y").is_error)

    def test_glob(self):
        r = self.run_tool("glob", pattern="**/*.py")
        self.assertIn("src/a.py", r.output.replace("\\", "/"))
        self.assertNotIn("node_modules", r.output)
        r = self.run_tool("glob", pattern="src/*.{py,txt}")
        self.assertIn("b.txt", r.output)

    def test_grep(self):
        r = self.run_tool("grep", pattern="TODO")
        self.assertIn("a.py:4", r.output.replace("\\", "/"))
        self.assertNotIn("node_modules", r.output)
        self.assertTrue(self.run_tool("grep", pattern="(").is_error)

    def test_bash(self):
        self.assertIn("hi", self.run_tool("bash", command="echo hi").output)
        r = self.run_tool("bash", command="exit 3")
        self.assertTrue(r.is_error)
        self.assertIn("3", r.output)

    def test_ls(self):
        r = self.run_tool("ls")
        self.assertIn("src/", r.output)


class ProviderConvertTests(unittest.TestCase):
    hist = [
        {"role": "user", "content": "selam"},
        {"role": "assistant", "content": "", "tool_calls": [
            {"id": "1", "name": "ls", "args": {}}, {"id": "2", "name": "read", "args": {"path": "x"}}]},
        {"role": "tool", "tool_call_id": "1", "name": "ls", "content": "a"},
        {"role": "tool", "tool_call_id": "2", "name": "read", "content": "b", "is_error": True},
    ]

    def test_anthropic_merges_tool_results(self):
        msgs = Anthropic.convert(self.hist)
        self.assertEqual([m["role"] for m in msgs], ["user", "assistant", "user"])
        self.assertEqual(len(msgs[2]["content"]), 2)
        self.assertTrue(msgs[2]["content"][1]["is_error"])

    def test_openai_format(self):
        msgs = OpenAICompat.convert(self.hist, "sys")
        self.assertEqual([m["role"] for m in msgs], ["system", "user", "assistant", "tool", "tool"])
        self.assertEqual(json.loads(msgs[2]["tool_calls"][1]["function"]["arguments"]), {"path": "x"})


class E2ETests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv, cls.url = mock_server.start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        mock_server.REQUESTS.clear()
        self.tmp = tempfile.TemporaryDirectory()
        self.cwd = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def agent(self, kind, auto=True, interactive=False, model="m"):
        cls = OpenAICompat if kind == "openai" else Anthropic
        spec = {"name": kind, "model": model}
        base = self.url if kind == "anthropic" else self.url
        return Agent(cls(base, "key", model), spec, self.cwd, auto_approve=auto, interactive=interactive)

    def test_openai_tool_loop(self):
        a = self.agent("openai")
        buf = io.StringIO()
        with redirect_stdout(buf):
            a.run("hello.txt yaz")
        out = buf.getvalue()
        self.assertEqual((self.cwd / "hello.txt").read_text(encoding="utf-8"), "merhaba\ndünya\n")
        self.assertIn("Write", out)
        self.assertIn("Bitti!", out)
        self.assertIn("250↑", out)  # 100+150 token toplamı
        roles = [m["role"] for m in a.history]
        self.assertEqual(roles, ["user", "assistant", "tool", "assistant"])
        self.assertEqual(len(mock_server.REQUESTS), 2)
        self.assertEqual(mock_server.REQUESTS[0]["headers"].get("authorization"), "Bearer key")

    def test_anthropic_tool_loop(self):
        a = self.agent("anthropic")
        buf = io.StringIO()
        with redirect_stdout(buf):
            a.run("selam de")
        self.assertIn("Komut çıktısı: selam", buf.getvalue())
        self.assertIn("selam", a.history[2]["content"])
        req = mock_server.REQUESTS[1]["body"]
        self.assertEqual(req["messages"][-1]["content"][0]["type"], "tool_result")
        self.assertEqual(mock_server.REQUESTS[0]["headers"].get("x-api-key"), "key")
        self.assertTrue(all("input_schema" in t for t in mock_server.REQUESTS[0]["body"]["tools"]))

    def test_permission_denied_non_interactive(self):
        a = self.agent("openai", auto=False, interactive=False)
        with redirect_stdout(io.StringIO()):
            a.run("yaz")
        self.assertFalse((self.cwd / "hello.txt").exists())
        self.assertIn("reddetti", a.history[2]["content"])

    def test_plan_mode_blocks_write_and_hides_tools(self):
        a = self.agent("openai")
        a.mode = "plan"
        with redirect_stdout(io.StringIO()):
            a.run("yaz")
        self.assertFalse((self.cwd / "hello.txt").exists())
        names = [t["function"]["name"] for t in mock_server.REQUESTS[0]["body"]["tools"]]
        self.assertNotIn("write", names)
        self.assertNotIn("bash", names)
        self.assertIn("read", names)

    def test_http_error_is_reported_and_history_clean(self):
        a = self.agent("openai", model="bad")
        buf = io.StringIO()
        with redirect_stdout(buf):
            a.run("x")
        self.assertIn("Incorrect API key", buf.getvalue())
        self.assertEqual(a.history, [])

    def test_compact(self):
        a = self.agent("openai")
        with redirect_stdout(io.StringIO()):
            a.run("yaz")
            self.assertTrue(a.compact())
        self.assertEqual(len(a.history), 2)

    def test_connection_error(self):
        a = Agent(OpenAICompat("http://127.0.0.1:1", "k", "m"), {"name": "x", "model": "m"}, self.cwd)
        buf = io.StringIO()
        with redirect_stdout(buf):
            a.run("x")
        self.assertIn("Bağlantı hatası", buf.getvalue())


class MarkdownTests(unittest.TestCase):
    def test_stream_chunks(self):
        buf = io.StringIO()
        with redirect_stdout(buf):
            md = ui.MarkdownStream()
            for ch in "# Başlık\n- madde `kod`\n```py\nx = 1\n```\nson":
                md.feed(ch)
            md.finish()
        text = buf.getvalue()
        self.assertIn("Başlık", text)
        self.assertIn("• madde kod", text)
        self.assertIn("x = 1", text)
        self.assertTrue(text.rstrip().endswith("son"))

    def test_color_output_has_ansi(self):
        ui.init_color(True)
        ui._state["truecolor"] = True
        try:
            self.assertIn("\x1b[38;2;250;178;131m", ui.style("x", "primary"))
        finally:
            ui.init_color(False)


if __name__ == "__main__":
    unittest.main()
