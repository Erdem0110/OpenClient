# OpenClient

Terminalde çalışan, OpenCode tarzı yapay zekâ kodlama asistanı. **Sıfır bağımlılık** (sadece Python ≥ 3.9 standart kütüphanesi), Windows / macOS / Linux.

## Kurulum ve çalıştırma

```bash
cd openclient
python -m openclient            # doğrudan çalıştır
# veya komut olarak kur:
pip install -e .
openclient
```

İlk açılışta `/connect` yaz, sağlayıcıyı seç ve API anahtarını gir (gizli girilir, `~/.config/openclient/config.json` içine kaydedilir; Windows'ta `%APPDATA%\openclient`).
Ortam değişkeni de olur: `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `OPENROUTER_API_KEY`.

## Sağlayıcılar

| ad | not |
|---|---|
| `anthropic` | Claude (Messages API) |
| `openai` | OpenAI Chat Completions |
| `openrouter` | yüzlerce model |
| `ollama` | yerel modeller, anahtar gerekmez (`http://localhost:11434/v1`) |
| `custom` | herhangi bir OpenAI uyumlu sunucu (LM Studio, vLLM, llama.cpp …) |

Model değiştirmek: `/model <ad>` veya `/model openai gpt-4.1`. Varsayılan model adları yapılandırılabilir; güncel olmayabilir.

## Kullanım

```
openclient                       # etkileşimli mod
openclient "testleri düzelt"     # tek seferlik çalıştır
openclient -p ollama -m qwen2.5-coder --plan
openclient -c                    # son oturumu sürdür
```

| komut | açıklama |
|---|---|
| `/connect` | API anahtarı gir / sağlayıcı seç |
| `/model`, `/models` | model göster-değiştir / sağlayıcıları listele |
| `/plan`, `/build` | salt-okunur plan modu / düzenleme+komut modu |
| `/init` | projeyi inceleyip `AGENTS.md` yazdır |
| `/compact` | bağlamı özetleyip küçült |
| `/new`, `/sessions`, `/resume <id>` | oturum yönetimi |
| `/yolo` | tüm izinleri otomatik onayla (dikkat) |
| `!komut` | kabukta doğrudan komut |
| `\` (satır sonu) | çok satırlı girdi |

## Araçlar

`read`, `write`, `edit`, `bash`, `glob`, `grep`, `ls`, `webfetch`.
`write`, `edit` ve `bash` çalışmadan önce izin ister: **y** bir kez, **a** oturum boyunca, **n** reddet. Plan modunda bu araçlar tamamen kapalıdır.

Proje kuralları için çalışma dizininde (veya üstünde) `AGENTS.md` / `CLAUDE.md` bulunursa sistem istemine eklenir.

## Test

```bash
python -m unittest discover -s tests -v
```
