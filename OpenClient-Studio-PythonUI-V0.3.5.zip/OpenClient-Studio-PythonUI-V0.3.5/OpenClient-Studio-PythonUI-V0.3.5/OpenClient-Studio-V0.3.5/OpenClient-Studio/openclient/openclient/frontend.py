"""Ajanın konuştuğu 'ön yüz' arayüzü.

Ajan (agent.py) ekrana doğrudan yazmaz; bu arayüzün metotlarını çağırır.
- TerminalFrontend: ANSI renkli terminal (ui.py)
- web.WebFrontend : masaüstü pencere uygulaması
- Frontend        : sessiz taban sınıf (testler / başsız kullanım)
"""

from __future__ import annotations

from . import ui


class Frontend:
    def begin_thinking(self, label: str = "Düşünüyor") -> None: ...
    def text(self, chunk: str) -> None: ...
    def text_end(self) -> None: ...
    def tool_start(self, name: str, summary: str, status: str = "run") -> None: ...
    def tool_output(self, text: str, is_error: bool = False) -> None: ...
    def tool_diff(self, diff: str) -> None: ...
    def tool_note(self, text: str, level: str = "muted") -> None: ...  # muted|success|error
    def show_preview(self, preview: dict | None) -> None: ...
    def notice(self, level: str, text: str) -> None: ...  # info|warn|error
    def footer(self, agent: str, model: str, seconds: float, tin: int, tout: int) -> None: ...

    def ask_permission(self, tool: str, summary: str, preview: dict | None) -> str:
        """'once' | 'always' | 'deny'"""
        return "deny"


class TerminalFrontend(Frontend):
    def __init__(self) -> None:
        self._spinner: ui.Spinner | None = None
        self._md: ui.MarkdownStream | None = None

    def begin_thinking(self, label: str = "Düşünüyor") -> None:
        self._spinner = ui.Spinner(label)
        self._md = ui.MarkdownStream(on_first_output=self._spinner.stop)
        self._spinner.start()

    def text(self, chunk: str) -> None:
        if self._md is None:
            self._md = ui.MarkdownStream()
        self._md.feed(chunk)

    def text_end(self) -> None:
        if self._spinner:
            self._spinner.stop()
        if self._md:
            self._md.finish()
        self._spinner = self._md = None

    def tool_start(self, name: str, summary: str, status: str = "run") -> None:
        ui.tool_header(name, summary, status)

    def tool_output(self, text: str, is_error: bool = False) -> None:
        ui.tool_output(text, 8, is_error)

    def tool_diff(self, diff: str) -> None:
        ui.print_diff(diff)

    def tool_note(self, text: str, level: str = "muted") -> None:
        ui.out(ui.style("  │ ", "border") + ui.style(text, level))

    def show_preview(self, preview: dict | None) -> None:
        if not preview:
            return
        if preview["kind"] == "diff":
            ui.print_diff(preview["text"])
        else:
            ui.tool_output(preview["text"], 7)

    def notice(self, level: str, text: str) -> None:
        {"info": ui.info, "warn": ui.warn, "error": ui.error}.get(level, ui.info)(text)

    def footer(self, agent: str, model: str, seconds: float, tin: int, tout: int) -> None:
        ui.footer(agent, model, seconds, tin, tout)

    def ask_permission(self, tool: str, summary: str, preview: dict | None) -> str:
        self.show_preview(preview)
        return ui.ask_permission(tool, summary)
