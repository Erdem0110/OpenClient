"""Ajanın kullandığı araçlar: read, write, edit, bash, glob, grep, ls, webfetch."""

from __future__ import annotations

import fnmatch
import os
import re
import subprocess
import urllib.error
import urllib.request
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Callable

from . import ui

IGNORED_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", ".mypy_cache", ".pytest_cache",
                ".idea", ".vscode", "dist", "build", ".next", "target"}
MAX_OUTPUT = 30_000


@dataclass
class ToolResult:
    output: str
    is_error: bool = False
    diff: str | None = None  # kullanıcıya gösterilecek diff


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    run: Callable[[dict, Path], ToolResult]
    summary: Callable[[dict], str]
    readonly: bool = True

    def spec(self) -> dict:
        return {"name": self.name, "description": self.description, "parameters": self.parameters}


def _resolve(path: str, cwd: Path) -> Path:
    p = Path(os.path.expanduser(path))
    return p if p.is_absolute() else (cwd / p)


def _rel(p: Path, cwd: Path) -> str:
    try:
        return str(p.relative_to(cwd))
    except ValueError:
        return str(p)


def _truncate(s: str, limit: int = MAX_OUTPUT) -> str:
    if len(s) <= limit:
        return s
    return s[:limit] + f"\n… [çıktı {len(s) - limit} karakter kısaltıldı]"


def _is_binary(data: bytes) -> bool:
    return b"\x00" in data[:4096]


def _walk(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in IGNORED_DIRS)
        for f in sorted(filenames):
            yield Path(dirpath) / f


# -- read -------------------------------------------------------------------

def _read(args: dict, cwd: Path) -> ToolResult:
    p = _resolve(args.get("path", ""), cwd)
    if not p.exists():
        return ToolResult(f"Dosya bulunamadı: {p}", True)
    if p.is_dir():
        return ToolResult(f"{p} bir dizin; 'ls' aracını kullan.", True)
    data = p.read_bytes()
    if _is_binary(data):
        return ToolResult(f"{p} ikili (binary) bir dosya, okunamaz.", True)
    lines = data.decode("utf-8", errors="replace").splitlines()
    offset = max(1, int(args.get("offset") or 1))
    limit = int(args.get("limit") or 2000)
    chunk = lines[offset - 1: offset - 1 + limit]
    body = "\n".join(f"{i:>6}\t{ln[:2000]}" for i, ln in enumerate(chunk, start=offset))
    if offset - 1 + limit < len(lines):
        body += f"\n… (toplam {len(lines)} satır; devamı için offset={offset + limit} kullan)"
    return ToolResult(body or "(boş dosya)")


# -- write ------------------------------------------------------------------

def _write(args: dict, cwd: Path) -> ToolResult:
    p = _resolve(args.get("path", ""), cwd)
    content = args.get("content")
    if content is None:
        return ToolResult("'content' parametresi gerekli.", True)
    old = ""
    existed = p.exists()
    if existed:
        try:
            old = p.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            old = ""
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8", newline="\n")
    verb = "güncellendi" if existed else "oluşturuldu"
    return ToolResult(f"{_rel(p, cwd)} {verb} ({len(content.splitlines())} satır).",
                      diff=ui.render_diff(old, content, _rel(p, cwd)))


# -- edit -------------------------------------------------------------------

def _edit(args: dict, cwd: Path) -> ToolResult:
    p = _resolve(args.get("path", ""), cwd)
    old, new = args.get("old_string"), args.get("new_string")
    if old is None or new is None:
        return ToolResult("'old_string' ve 'new_string' gerekli.", True)
    if old == new:
        return ToolResult("old_string ve new_string aynı.", True)
    if not p.is_file():
        return ToolResult(f"Dosya bulunamadı: {p}", True)
    text = p.read_text(encoding="utf-8")
    count = text.count(old)
    if count == 0:
        return ToolResult("old_string dosyada bulunamadı (boşluk/girinti birebir aynı olmalı).", True)
    if count > 1 and not args.get("replace_all"):
        return ToolResult(f"old_string {count} yerde geçiyor; daha fazla bağlam ekle veya replace_all=true kullan.", True)
    updated = text.replace(old, new) if args.get("replace_all") else text.replace(old, new, 1)
    p.write_text(updated, encoding="utf-8", newline="\n")
    return ToolResult(f"{_rel(p, cwd)} düzenlendi ({count if args.get('replace_all') else 1} değişiklik).",
                      diff=ui.render_diff(text, updated, _rel(p, cwd)))


# -- bash -------------------------------------------------------------------

def _bash(args: dict, cwd: Path) -> ToolResult:
    cmd = args.get("command", "")
    if not cmd.strip():
        return ToolResult("'command' gerekli.", True)
    timeout = min(int(args.get("timeout") or 120), 600)
    try:
        proc = subprocess.run(cmd, shell=True, cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              stdin=subprocess.DEVNULL, timeout=timeout, text=True, encoding="utf-8",
                              errors="replace", creationflags=0x08000000 if os.name == "nt" else 0)
    except subprocess.TimeoutExpired as e:
        partial = (e.stdout or "") if isinstance(e.stdout, str) else ""
        return ToolResult(_truncate(partial) + f"\n[{timeout} sn zaman aşımı, komut durduruldu]", True)
    out = _truncate(proc.stdout or "")
    if proc.returncode != 0:
        return ToolResult(f"{out}\n[çıkış kodu {proc.returncode}]".strip(), True)
    return ToolResult(out or "(çıktı yok)")


# -- glob / grep / ls -------------------------------------------------------

def _glob(args: dict, cwd: Path) -> ToolResult:
    pattern = args.get("pattern", "")
    root = _resolve(args.get("path") or ".", cwd)
    if not root.is_dir():
        return ToolResult(f"Dizin yok: {root}", True)
    pat = pattern.replace("\\", "/")
    rx = re.compile(_glob_to_regex(pat))
    matches = []
    for f in _walk(root):
        rel = f.relative_to(root).as_posix()
        if rx.fullmatch(rel):
            matches.append(f)
    matches.sort(key=lambda f: f.stat().st_mtime, reverse=True)
    if not matches:
        return ToolResult("Eşleşen dosya yok.")
    shown = [_rel(f, cwd) for f in matches[:200]]
    extra = f"\n… {len(matches) - 200} sonuç daha" if len(matches) > 200 else ""
    return ToolResult("\n".join(shown) + extra)


def _glob_to_regex(pat: str) -> str:
    i, n, res = 0, len(pat), ""
    while i < n:
        c = pat[i]
        if c == "*":
            if pat[i:i + 3] == "**/":
                res += "(?:.*/)?"
                i += 3
                continue
            if pat[i:i + 2] == "**":
                res += ".*"
                i += 2
                continue
            res += "[^/]*"
        elif c == "?":
            res += "[^/]"
        elif c == "{":
            j = pat.find("}", i)
            if j == -1:
                res += re.escape(c)
            else:
                res += "(?:" + "|".join(re.escape(x) for x in pat[i + 1:j].split(",")) + ")"
                i = j
        else:
            res += re.escape(c)
        i += 1
    return res


def _grep(args: dict, cwd: Path) -> ToolResult:
    pattern = args.get("pattern", "")
    root = _resolve(args.get("path") or ".", cwd)
    include = args.get("include")
    try:
        rx = re.compile(pattern)
    except re.error as e:
        return ToolResult(f"Geçersiz regex: {e}", True)
    files = [root] if root.is_file() else _walk(root)
    results, total = [], 0
    for f in files:
        if include and not fnmatch.fnmatch(f.name, include):
            continue
        try:
            if f.stat().st_size > 2_000_000:
                continue
            data = f.read_bytes()
        except OSError:
            continue
        if _is_binary(data):
            continue
        for i, line in enumerate(data.decode("utf-8", errors="replace").splitlines(), 1):
            if rx.search(line):
                total += 1
                if len(results) < 100:
                    results.append(f"{_rel(f, cwd)}:{i}: {line.strip()[:300]}")
    if not results:
        return ToolResult("Eşleşme yok.")
    extra = f"\n… toplam {total} eşleşme, ilk 100 gösterildi" if total > 100 else ""
    return ToolResult("\n".join(results) + extra)


def _ls(args: dict, cwd: Path) -> ToolResult:
    p = _resolve(args.get("path") or ".", cwd)
    if not p.is_dir():
        return ToolResult(f"Dizin yok: {p}", True)
    entries = sorted(p.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower()))
    lines = [e.name + ("/" if e.is_dir() else "") for e in entries if e.name not in IGNORED_DIRS or e.is_dir()]
    return ToolResult("\n".join(lines[:500]) or "(boş dizin)")


# -- webfetch ---------------------------------------------------------------

class _Text(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "head"}

    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in ("p", "br", "div", "li", "h1", "h2", "h3", "h4", "tr"):
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1

    def handle_data(self, data):
        if not self.skip and data.strip():
            self.parts.append(data.strip() + " ")


def _webfetch(args: dict, cwd: Path) -> ToolResult:
    url = args.get("url", "")
    if not url.startswith(("http://", "https://")):
        return ToolResult("URL http:// veya https:// ile başlamalı.", True)
    req = urllib.request.Request(url, headers={"User-Agent": "OpenClient/0.1"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read(2_000_000)
            ctype = r.headers.get("content-type", "")
    except (urllib.error.URLError, OSError) as e:
        return ToolResult(f"İstek başarısız: {e}", True)
    text = raw.decode("utf-8", errors="replace")
    if "html" in ctype:
        parser = _Text()
        parser.feed(text)
        text = re.sub(r"\n\s*\n+", "\n\n", "".join(parser.parts))
    return ToolResult(_truncate(text, 50_000))


# --------------------------------------------------------------------------

def _obj(props: dict, required: list[str]) -> dict:
    return {"type": "object", "properties": props, "required": required}


_S = {"type": "string"}

TOOLS: list[Tool] = [
    Tool("read", "Bir dosyanın içeriğini satır numaralarıyla okur.",
         _obj({"path": {**_S, "description": "Dosya yolu"},
               "offset": {"type": "integer", "description": "Başlangıç satırı (1'den)"},
               "limit": {"type": "integer", "description": "En fazla satır sayısı"}}, ["path"]),
         _read, lambda a: a.get("path", "")),
    Tool("write", "Dosyayı verilen içerikle oluşturur veya tamamen değiştirir.",
         _obj({"path": _S, "content": _S}, ["path", "content"]),
         _write, lambda a: a.get("path", ""), readonly=False),
    Tool("edit", "Dosyada old_string metnini new_string ile değiştirir. old_string birebir ve benzersiz olmalı.",
         _obj({"path": _S, "old_string": _S, "new_string": _S, "replace_all": {"type": "boolean"}},
              ["path", "old_string", "new_string"]),
         _edit, lambda a: a.get("path", ""), readonly=False),
    Tool("bash", "Kabukta komut çalıştırır (git, test, derleme vb.). Çıktı stdout+stderr'dir.",
         _obj({"command": _S, "timeout": {"type": "integer", "description": "Saniye (varsayılan 120)"}},
              ["command"]),
         _bash, lambda a: a.get("command", "").strip().split("\n")[0][:120], readonly=False),
    Tool("glob", "Dosya adı desenine göre arama yapar (ör. **/*.py). En yeni değişenler önce.",
         _obj({"pattern": _S, "path": {**_S, "description": "Aranacak dizin (varsayılan: çalışma dizini)"}}, ["pattern"]),
         _glob, lambda a: a.get("pattern", "")),
    Tool("grep", "Dosya içeriğinde regex arar. Çıktı: yol:satır: metin",
         _obj({"pattern": _S, "path": _S, "include": {**_S, "description": "Dosya deseni, ör. *.py"}}, ["pattern"]),
         _grep, lambda a: a.get("pattern", "")),
    Tool("ls", "Bir dizinin içeriğini listeler.",
         _obj({"path": _S}, []), _ls, lambda a: a.get("path") or "."),
    Tool("webfetch", "Bir URL'yi indirir ve okunabilir metne çevirir.",
         _obj({"url": _S}, ["url"]), _webfetch, lambda a: a.get("url", "")),
]

BY_NAME = {t.name: t for t in TOOLS}


def specs(readonly_only: bool = False) -> list[dict]:
    return [t.spec() for t in TOOLS if t.readonly or not readonly_only]
