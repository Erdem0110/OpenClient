"""Ajan döngüsü: model → araç çağrıları → izin → sonuç → model ..."""

from __future__ import annotations

import datetime
import os
import platform
import threading
import time
from pathlib import Path

from . import tools
from .frontend import Frontend, TerminalFrontend
from .providers import ProviderError, Turn

MAX_STEPS = 60

BASE_PROMPT = """You are OpenClient, an interactive terminal coding agent. You help the user with software \
engineering tasks (fixing bugs, adding features, refactoring, explaining code, running commands) \
by using the tools available to you.

# How to work
- Be concise and direct: your output is shown in a terminal. Avoid preamble and avoid repeating what tools already showed.
- Reply in the same language the user writes in.
- Explore before you change things: use ls/glob/grep/read to understand the code and follow its existing conventions.
- Prefer `edit` for changes to existing files and `write` only for new files. Always read a file before editing it.
- Make the smallest change that solves the task. Do not add comments, files or refactors nobody asked for.
- After changing code, verify it when practical (run tests, linters, or the program) with `bash`.
- Never run destructive commands (rm -rf, git reset --hard, force pushes ...) unless the user asked for it.
- When referencing code, use the form `path/to/file.py:42`.
- If a request is ambiguous in a way that matters, ask one short question instead of guessing.
"""

PLAN_PROMPT = """
# PLAN MODE
You are in read-only plan mode. You may read, search and fetch, but you must NOT modify files or run \
shell commands (those tools are disabled). Analyse the task and produce a clear, step-by-step plan \
that the user can approve; mention the exact files and functions you would change.
"""


def load_project_rules(cwd: Path) -> str:
    names = ("AGENTS.md", "CLAUDE.md")
    home = Path.home()
    for d in [cwd, *cwd.parents]:
        for n in names:
            f = d / n
            if f.is_file():
                try:
                    return f"\n# Project rules ({f})\n" + f.read_text(encoding="utf-8")[:20000]
                except OSError:
                    pass
        if d == home:
            break
    return ""



class Agent:
    def __init__(self, provider, spec: dict, cwd: Path, auto_approve: bool = False,
                 interactive: bool = True, frontend: Frontend | None = None) -> None:
        self.provider = provider
        self.spec = spec
        self.cwd = cwd
        self.auto_approve = auto_approve
        self.interactive = interactive
        self.fe: Frontend = frontend or TerminalFrontend()
        self.mode = "build"
        self.history: list[dict] = []
        self.always: set[str] = set()
        self.last_usage = (0, 0)
        self.cancel = threading.Event()  # GUI'de "Durdur" düğmesi
        self._asked = False

    # -- sistem istemi ------------------------------------------------------
    def system_prompt(self) -> str:
        env = (f"\n# Environment\n- Working directory: {self.cwd}\n- Platform: {platform.system()} "
               f"({os.name})\n- Date: {datetime.date.today().isoformat()}\n- Shell: "
               f"{'cmd/PowerShell' if os.name == 'nt' else os.environ.get('SHELL', 'sh')}\n")
        return BASE_PROMPT + (PLAN_PROMPT if self.mode == "plan" else "") + env + load_project_rules(self.cwd)

    def set_provider(self, provider, spec: dict) -> None:
        self.provider, self.spec = provider, spec

    def _on_text(self, chunk: str) -> None:
        if self.cancel.is_set():
            raise KeyboardInterrupt
        self.fe.text(chunk)

    # -- izin ---------------------------------------------------------------
    @staticmethod
    def _preview(name: str, args: dict) -> dict | None:
        if name == "edit":
            old = "\n".join("-" + ln for ln in str(args.get("old_string", "")).splitlines())
            new = "\n".join("+" + ln for ln in str(args.get("new_string", "")).splitlines())
            return {"kind": "diff", "text": f"--- {args.get('path', '')}\n{old}\n{new}"}
        if name == "write":
            body = str(args.get("content", "")).splitlines()
            return {"kind": "text", "text": "\n".join(body[:6]) + (f"\n… {len(body)} satır" if len(body) > 6 else "")}
        return None

    def _allowed(self, tool: tools.Tool, args: dict) -> bool:
        if tool.readonly or self.auto_approve or tool.name in self.always:
            return True
        preview = self._preview(tool.name, args)
        self._asked = True
        if not self.interactive:
            self.fe.show_preview(preview)
            return False
        choice = self.fe.ask_permission(tool.name, tool.summary(args), preview)
        if choice == "always":
            self.always.add(tool.name)
        return choice != "deny"

    # -- ana döngü ----------------------------------------------------------
    def run(self, user_text: str) -> None:
        self.cancel.clear()
        self.history.append({"role": "user", "content": user_text})
        t0 = time.time()
        tin = tout = 0
        for _ in range(MAX_STEPS):
            self.fe.begin_thinking()
            try:
                turn: Turn = self.provider.stream(self.history, self.system_prompt(),
                                                  tools.specs(self.mode == "plan"), self._on_text)
            except KeyboardInterrupt:
                self.fe.text_end()
                self.fe.notice("warn", "Yanıt durduruldu.")
                return
            except ProviderError as e:
                self.fe.text_end()
                self.fe.notice("error", str(e))
                self._drop_dangling_user()
                return
            except Exception as e:  # ağ kopması vb.
                self.fe.text_end()
                self.fe.notice("error", f"Beklenmeyen hata: {type(e).__name__}: {e}")
                self._drop_dangling_user()
                return
            self.fe.text_end()
            tin += turn.tokens_in
            tout += turn.tokens_out

            self.history.append({"role": "assistant", "content": turn.text, "tool_calls": turn.tool_calls})
            if not turn.tool_calls:
                break
            if not self._run_tools(turn.tool_calls):
                break
            if turn.stop_reason == "max_tokens":
                self.fe.notice("warn", "Yanıt token sınırına takıldı.")
        else:
            self.fe.notice("warn", f"{MAX_STEPS} adım sınırına ulaşıldı; devam etmek için bir şey yaz.")
        self.last_usage = (tin, tout)
        self.fe.footer(self.mode, self.spec["model"], time.time() - t0, tin, tout)

    def _drop_dangling_user(self) -> None:
        # hata olduysa son kullanıcı mesajı yanıtsız kalmasın diye geri al
        if self.history and self.history[-1]["role"] == "user":
            self.history.pop()

    def _run_tools(self, calls: list[dict]) -> bool:
        """Araçları çalıştırır. Kesilirse False döner (tüm çağrılar yine de yanıtlanır)."""
        done: set[str] = set()
        try:
            for call in calls:
                if self.cancel.is_set():
                    raise KeyboardInterrupt
                self._exec(call)
                done.add(call["id"])
            return True
        except KeyboardInterrupt:
            self.fe.notice("warn", "Durduruldu.")
            return False
        finally:
            answered = {m.get("tool_call_id") for m in self.history[-len(calls) - 1:] if m["role"] == "tool"}
            for call in calls:
                if call["id"] not in done and call["id"] not in answered:
                    self.history.append({"role": "tool", "tool_call_id": call["id"], "name": call["name"],
                                         "content": "Kullanıcı tarafından durduruldu.", "is_error": True})

    def _exec(self, call: dict) -> None:
        name, args = call["name"], call["args"]
        self._asked = False
        tool = tools.BY_NAME.get(name)
        fe = self.fe
        result: tools.ToolResult
        if tool is None:
            result = tools.ToolResult(f"Bilinmeyen araç: {name}", True)
            fe.tool_start(name, "", "error")
        elif "_invalid_json" in args:
            result = tools.ToolResult("Araç argümanları geçerli JSON değil, tekrar dene.", True)
            fe.tool_start(name, "geçersiz argüman", "error")
        elif self.mode == "plan" and not tool.readonly:
            result = tools.ToolResult("Plan modunda bu araç kapalı. Kullanıcı /build ile moda geçmeli.", True)
            fe.tool_start(name, tool.summary(args), "error")
        else:
            fe.tool_start(name, tool.summary(args))
            if not self._allowed(tool, args):
                result = tools.ToolResult("Kullanıcı bu işlemi reddetti.", True)
                fe.tool_note("reddedildi", "error")
            else:
                try:
                    result = tool.run(args, self.cwd)
                except KeyboardInterrupt:
                    raise
                except Exception as e:
                    result = tools.ToolResult(f"Araç hatası: {type(e).__name__}: {e}", True)
                if result.diff and not (self._asked and not result.is_error):
                    fe.tool_diff(result.diff)
                elif result.diff:
                    fe.tool_note(result.output, "success")
                elif tool.name in ("bash", "grep", "glob", "webfetch") or result.is_error:
                    fe.tool_output(result.output, result.is_error)
                elif tool.name == "read":
                    fe.tool_note(f"{len(result.output.splitlines())} satır", "muted")
        self.history.append({"role": "tool", "tool_call_id": call["id"], "name": name,
                             "content": tools._truncate(result.output), "is_error": result.is_error})

    # -- yardımcılar --------------------------------------------------------
    def compact(self) -> bool:
        if len(self.history) < 4:
            self.fe.notice("info", "Sıkıştırılacak kadar konuşma yok.")
            return False
        self.cancel.clear()
        msgs = self.history + [{"role": "user", "content": (
            "Summarize our conversation so far so work can continue in a fresh context: goals, decisions, "
            "files touched, current state and next steps. Be compact but complete.")}]
        self.fe.begin_thinking("Özetleniyor")
        try:
            turn = self.provider.stream(msgs, self.system_prompt(), [], lambda c: None)
        except (ProviderError, KeyboardInterrupt) as e:
            self.fe.text_end()
            self.fe.notice("error", str(e) or "durduruldu")
            return False
        self.fe.text_end()
        self.history = [
            {"role": "user", "content": "Önceki konuşmanın özeti:\n\n" + turn.text},
            {"role": "assistant", "content": "Özeti aldım, devam edebiliriz.", "tool_calls": []},
        ]
        self.fe.notice("info", f"Bağlam sıkıştırıldı ({turn.tokens_out:,} token özet).")
        return True
