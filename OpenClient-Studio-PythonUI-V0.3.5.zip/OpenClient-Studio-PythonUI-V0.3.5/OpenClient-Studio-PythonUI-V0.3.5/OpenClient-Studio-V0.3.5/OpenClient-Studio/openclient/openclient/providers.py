"""LLM sağlayıcıları: Anthropic Messages API ve OpenAI uyumlu Chat Completions (streaming).

Dahili mesaj formatı:
  {"role": "user", "content": str}
  {"role": "assistant", "content": str, "tool_calls": [{"id", "name", "args": dict}]}
  {"role": "tool", "tool_call_id": str, "name": str, "content": str}
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Callable, Iterator


class ProviderError(Exception):
    pass


@dataclass
class Turn:
    text: str = ""
    tool_calls: list[dict] = field(default_factory=list)
    tokens_in: int = 0
    tokens_out: int = 0
    stop_reason: str | None = None


def _sse(resp) -> Iterator[tuple[str | None, str]]:
    """Server-Sent Events: (event, data) çiftleri üretir."""
    event = None
    data: list[str] = []
    for raw in resp:
        line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
        if not line:
            if data:
                yield event, "\n".join(data)
            event, data = None, []
        elif line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data.append(line[5:].lstrip())
    if data:
        yield event, "\n".join(data)


def _post(url: str, headers: dict, body: dict, timeout: float = 600):
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        try:
            j = json.loads(detail)
            detail = (j.get("error") or {}).get("message") or j.get("message") or detail
        except (json.JSONDecodeError, AttributeError):
            pass
        hint = ""
        if e.code in (401, 403):
            hint = "  (API anahtarını kontrol et: /connect)"
        raise ProviderError(f"HTTP {e.code}: {str(detail)[:500]}{hint}") from None
    except urllib.error.URLError as e:
        raise ProviderError(f"Bağlantı hatası ({url}): {e.reason}") from None


def _parse_args(raw: str) -> dict:
    if not raw or not raw.strip():
        return {}
    try:
        v = json.loads(raw)
        return v if isinstance(v, dict) else {"_value": v}
    except json.JSONDecodeError:
        return {"_invalid_json": raw}


# --------------------------------------------------------------------------

class Anthropic:
    def __init__(self, base_url: str, api_key: str | None, model: str, max_tokens: int = 8192) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.max_tokens = max_tokens

    @staticmethod
    def convert(messages: list[dict]) -> list[dict]:
        res: list[dict] = []
        for m in messages:
            role = m["role"]
            if role == "user":
                res.append({"role": "user", "content": m["content"]})
            elif role == "assistant":
                blocks: list[dict] = []
                if m.get("content"):
                    blocks.append({"type": "text", "text": m["content"]})
                for tc in m.get("tool_calls", []):
                    blocks.append({"type": "tool_use", "id": tc["id"], "name": tc["name"], "input": tc["args"]})
                if blocks:
                    res.append({"role": "assistant", "content": blocks})
            elif role == "tool":
                block = {"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m["content"]}
                if m.get("is_error"):
                    block["is_error"] = True
                if res and res[-1]["role"] == "user" and isinstance(res[-1]["content"], list):
                    res[-1]["content"].append(block)
                else:
                    res.append({"role": "user", "content": [block]})
        return res

    def stream(self, messages: list[dict], system: str, tools: list[dict],
               on_text: Callable[[str], None]) -> Turn:
        if not self.api_key:
            raise ProviderError("API anahtarı yok. /connect ile ekle veya ANTHROPIC_API_KEY ayarla.")
        body = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "system": system,
            "messages": self.convert(messages),
            "stream": True,
        }
        if tools:
            body["tools"] = [{"name": t["name"], "description": t["description"],
                              "input_schema": t["parameters"]} for t in tools]
        headers = {"content-type": "application/json", "x-api-key": self.api_key,
                   "anthropic-version": "2023-06-01", "accept": "text/event-stream"}
        turn = Turn()
        blocks: dict[int, dict] = {}
        with _post(f"{self.base_url}/v1/messages", headers, body) as resp:
            for _event, data in _sse(resp):
                try:
                    ev = json.loads(data)
                except json.JSONDecodeError:
                    continue
                t = ev.get("type")
                if t == "message_start":
                    turn.tokens_in = (ev.get("message", {}).get("usage") or {}).get("input_tokens", 0)
                elif t == "content_block_start":
                    cb = ev["content_block"]
                    blocks[ev["index"]] = {"type": cb["type"], "id": cb.get("id"), "name": cb.get("name"), "json": ""}
                elif t == "content_block_delta":
                    d = ev["delta"]
                    if d.get("type") == "text_delta":
                        turn.text += d["text"]
                        on_text(d["text"])
                    elif d.get("type") == "input_json_delta":
                        blocks[ev["index"]]["json"] += d.get("partial_json", "")
                elif t == "content_block_stop":
                    b = blocks.get(ev["index"])
                    if b and b["type"] == "tool_use":
                        turn.tool_calls.append({"id": b["id"], "name": b["name"], "args": _parse_args(b["json"])})
                elif t == "message_delta":
                    turn.tokens_out = (ev.get("usage") or {}).get("output_tokens", turn.tokens_out)
                    turn.stop_reason = (ev.get("delta") or {}).get("stop_reason") or turn.stop_reason
                elif t == "error":
                    raise ProviderError((ev.get("error") or {}).get("message", "bilinmeyen akış hatası"))
        return turn


class OpenAICompat:
    def __init__(self, base_url: str, api_key: str | None, model: str, max_tokens: int = 8192) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.max_tokens = max_tokens

    @staticmethod
    def convert(messages: list[dict], system: str) -> list[dict]:
        res: list[dict] = [{"role": "system", "content": system}]
        for m in messages:
            role = m["role"]
            if role == "user":
                res.append({"role": "user", "content": m["content"]})
            elif role == "assistant":
                msg: dict = {"role": "assistant", "content": m.get("content") or None}
                if m.get("tool_calls"):
                    msg["tool_calls"] = [
                        {"id": tc["id"], "type": "function",
                         "function": {"name": tc["name"], "arguments": json.dumps(tc["args"], ensure_ascii=False)}}
                        for tc in m["tool_calls"]]
                res.append(msg)
            elif role == "tool":
                res.append({"role": "tool", "tool_call_id": m["tool_call_id"], "content": m["content"]})
        return res

    def stream(self, messages: list[dict], system: str, tools: list[dict],
               on_text: Callable[[str], None]) -> Turn:
        body = {
            "model": self.model,
            "messages": self.convert(messages, system),
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if tools:
            body["tools"] = [{"type": "function", "function": {
                "name": t["name"], "description": t["description"], "parameters": t["parameters"]}} for t in tools]
        headers = {"content-type": "application/json", "accept": "text/event-stream"}
        if self.api_key:
            headers["authorization"] = f"Bearer {self.api_key}"
        turn = Turn()
        calls: dict[int, dict] = {}
        with _post(f"{self.base_url}/chat/completions", headers, body) as resp:
            for _event, data in _sse(resp):
                if data.strip() == "[DONE]":
                    break
                try:
                    ev = json.loads(data)
                except json.JSONDecodeError:
                    continue
                if ev.get("error"):
                    err = ev["error"]
                    raise ProviderError(err.get("message", str(err)) if isinstance(err, dict) else str(err))
                if ev.get("usage"):
                    turn.tokens_in = ev["usage"].get("prompt_tokens", 0)
                    turn.tokens_out = ev["usage"].get("completion_tokens", 0)
                for ch in ev.get("choices") or []:
                    d = ch.get("delta") or {}
                    if d.get("content"):
                        turn.text += d["content"]
                        on_text(d["content"])
                    for tc in d.get("tool_calls") or []:
                        slot = calls.setdefault(tc.get("index", 0), {"id": None, "name": "", "args": ""})
                        if tc.get("id"):
                            slot["id"] = tc["id"]
                        fn = tc.get("function") or {}
                        if fn.get("name"):
                            slot["name"] += fn["name"]
                        if fn.get("arguments"):
                            slot["args"] += fn["arguments"]
                    if ch.get("finish_reason"):
                        turn.stop_reason = ch["finish_reason"]
        for i in sorted(calls):
            c = calls[i]
            turn.tool_calls.append({"id": c["id"] or f"call_{i}", "name": c["name"], "args": _parse_args(c["args"])})
        return turn


def make_provider(spec: dict):
    cls = Anthropic if spec.get("type") == "anthropic" else OpenAICompat
    return cls(spec["base_url"], spec.get("api_key"), spec["model"], int(spec.get("max_tokens", 8192)))
