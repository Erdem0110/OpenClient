"""Komut satırı girişi ve etkileşimli REPL."""

from __future__ import annotations

import argparse
import getpass
import os
import sys
from pathlib import Path

from . import __version__, tools, ui
from .agent import Agent
from .config import (PRESETS, Config, list_sessions, load_session, new_session_id,
                     save_session)
from .providers import make_provider

COMMANDS = {
    "/help": "bu yardımı göster",
    "/connect": "sağlayıcı için API anahtarı gir ve seç",
    "/models": "sağlayıcıları ve durumlarını listele",
    "/model": "modeli göster/değiştir:  /model <ad>  veya  /model <sağlayıcı> <ad>",
    "/plan": "plan moduna geç (salt-okunur)",
    "/build": "build moduna geç (düzenleme + komut)",
    "/init": "projeyi inceleyip AGENTS.md oluştur",
    "/compact": "konuşmayı özetleyip bağlamı küçült",
    "/new": "yeni oturum başlat (/clear ile aynı)",
    "/clear": "yeni oturum başlat",
    "/sessions": "son oturumları listele",
    "/resume": "oturumu sürdür:  /resume <id>",
    "/yolo": "tüm izinleri otomatik onayla / kapat",
    "/exit": "çık (/quit)",
}


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="openclient", description="OpenClient - terminal yapay zekâ kodlama asistanı")
    p.add_argument("prompt", nargs="*", help="verilirse tek seferlik çalışır ve çıkar")
    p.add_argument("-m", "--model", help="model adı")
    p.add_argument("-p", "--provider", help="sağlayıcı: " + ", ".join(PRESETS))
    p.add_argument("--base-url", help="API taban adresi (OpenAI uyumlu sunucular için)")
    p.add_argument("--plan", action="store_true", help="plan (salt-okunur) modunda başla")
    p.add_argument("-y", "--yes", action="store_true", help="tüm araç izinlerini otomatik onayla")
    p.add_argument("-c", "--continue", dest="cont", action="store_true", help="son oturumu sürdür")
    p.add_argument("--no-color", action="store_true", help="renkleri kapat")
    p.add_argument("-v", "--version", action="version", version=f"OpenClient {__version__}")
    return p.parse_args(argv)


class Session:
    def __init__(self, cfg: Config, agent: Agent) -> None:
        self.cfg = cfg
        self.agent = agent
        self.id = new_session_id()

    def save(self) -> None:
        if self.agent.history:
            save_session(self.id, self.agent.history, {
                "cwd": str(self.agent.cwd), "model": self.agent.spec["model"],
                "provider": self.agent.spec["name"],
                "title": next((m["content"][:60] for m in self.agent.history if m["role"] == "user"), ""),
            })

    def switch(self, spec: dict) -> None:
        self.agent.set_provider(make_provider(spec), spec)

    def reset(self) -> None:
        self.agent.history = []
        self.id = new_session_id()


def _cmd_help() -> None:
    ui.out()
    for c, d in COMMANDS.items():
        ui.out("  " + ui.style(c.ljust(11), "primary") + ui.style(d, "muted"))
    ui.out("  " + ui.style("!komut".ljust(11), "primary") + ui.style("kabukta doğrudan komut çalıştır", "muted"))
    ui.out("  " + ui.style("\\ ".ljust(11), "primary") + ui.style("satır sonuna koyarsan çok satırlı yazarsın", "muted"))
    ui.out("  " + ui.style("Ctrl+C".ljust(11), "primary") + ui.style("yanıtı durdur (boş istemde iki kez: çıkış)", "muted"))
    ui.out()


def _cmd_models(s: Session) -> None:
    ui.out()
    for name in s.cfg.provider_names():
        spec = s.cfg.resolve(name)
        ready = bool(spec.get("api_key")) or not spec.get("env")
        mark = ui.style("●", "success") if ready else ui.style("○", "border")
        cur = ui.style("  ← aktif", "primary") if name == s.agent.spec["name"] else ""
        ui.out(f"  {mark} " + ui.style(name.ljust(11), "text") + ui.style(spec["model"], "muted") + cur)
    ui.out()
    ui.out(ui.style("  ● hazır   ○ anahtar yok (/connect)", "muted"))
    ui.out()


def _cmd_connect(s: Session, arg: str) -> None:
    names = s.cfg.provider_names()
    name = arg.strip()
    if not name:
        ui.out()
        for i, n in enumerate(names, 1):
            ui.out(f"  {ui.style(str(i), 'primary')}. {n}  " + ui.style(PRESETS.get(n, {}).get("label", ""), "muted"))
        try:
            ans = input("\n  Sağlayıcı (ad veya numara) › ").strip()
        except (EOFError, KeyboardInterrupt):
            ui.out()
            return
        name = names[int(ans) - 1] if ans.isdigit() and 1 <= int(ans) <= len(names) else ans
    if name not in names:
        ui.error(f"Bilinmeyen sağlayıcı: {name}")
        return
    spec = s.cfg.resolve(name)
    if spec.get("env"):
        try:
            key = getpass.getpass("  API anahtarı (gizli, boş = değiştirme) › ").strip()
        except (EOFError, KeyboardInterrupt):
            ui.out()
            return
        if key:
            s.cfg.set_key(name, key)
    if name == "custom" or name == "ollama":
        try:
            url = input(f"  Taban adres [{spec['base_url']}] › ").strip()
            mdl = input(f"  Model [{spec['model']}] › ").strip()
        except (EOFError, KeyboardInterrupt):
            ui.out()
            return
        prov = s.cfg.data.setdefault("providers", {}).setdefault(name, {})
        if url:
            prov["base_url"] = url
        if mdl:
            prov["model"] = mdl
        s.cfg.save()
    s.cfg.set_default(name, None)
    s.switch(s.cfg.resolve(name))
    ui.info(f"{name} seçildi — model: {s.agent.spec['model']}")


def _cmd_model(s: Session, arg: str) -> None:
    parts = arg.split()
    if not parts:
        ui.info(f"{s.agent.spec['name']} / {s.agent.spec['model']}")
        return
    if len(parts) >= 2 and parts[0] in s.cfg.provider_names():
        name, model = parts[0], parts[1]
    else:
        name, model = s.agent.spec["name"], parts[0]
    s.cfg.set_default(name, model)
    s.switch(s.cfg.resolve(name, model=model))
    ui.info(f"Model: {name} / {model}")


def _cmd_shell(s: Session, command: str) -> None:
    ui.tool_header("bash", command)
    res = tools.BY_NAME["bash"].run({"command": command}, s.agent.cwd)
    ui.tool_output(res.output, 60, res.is_error)


def handle_command(s: Session, text: str) -> str | None:
    """Komutu işler. Ajana iletilecek bir metin dönerse (ör. /init) onu döndürür."""
    if text.startswith("!"):
        _cmd_shell(s, text[1:].strip())
        return None
    cmd, _, arg = text.partition(" ")
    cmd = cmd.lower()
    if cmd not in COMMANDS and cmd != "/quit":
        ui.error(f"Bilinmeyen komut: {cmd}  (/help)")
        return None
    if cmd in ("/exit", "/quit"):
        raise EOFError
    if cmd == "/help":
        _cmd_help()
    elif cmd == "/connect":
        _cmd_connect(s, arg)
    elif cmd == "/models":
        _cmd_models(s)
    elif cmd == "/model":
        _cmd_model(s, arg)
    elif cmd in ("/plan", "/build"):
        s.agent.mode = cmd[1:]
        ui.info(f"Mod: {s.agent.mode}" + (" (salt-okunur)" if s.agent.mode == "plan" else ""))
    elif cmd in ("/new", "/clear"):
        s.reset()
        ui.info("Yeni oturum başladı.")
    elif cmd == "/compact":
        s.agent.compact()
        s.save()
    elif cmd == "/yolo":
        s.agent.auto_approve = not s.agent.auto_approve
        ui.warn("Tüm izinler otomatik onaylanacak." if s.agent.auto_approve else "İzin soruları geri açıldı.")
    elif cmd == "/sessions":
        ui.out()
        for sid, meta in list_sessions():
            ui.out("  " + ui.style(sid, "primary") + "  " + ui.style(meta.get("title", ""), "muted"))
        ui.out()
    elif cmd == "/resume":
        loaded = load_session(arg.strip()) if arg.strip() else None
        if not loaded:
            ui.error("Oturum bulunamadı. /sessions ile listele.")
        else:
            s.agent.history, _meta = loaded
            s.id = arg.strip()
            ui.info(f"{len(s.agent.history)} mesaj yüklendi.")
    elif cmd == "/init":
        return INIT_PROMPT
    return None


INIT_PROMPT = ("Bu projeyi incele (dizin yapısı, build/test komutları, kod stili, mimari) ve çalışma dizinine kısa, "
               "işe yarar bir AGENTS.md dosyası yaz: projenin amacı, önemli komutlar, konvansiyonlar. "
               "Zaten varsa iyileştir.")


def _setup_completion() -> None:
    if not ui.HAS_READLINE:
        return
    import readline

    def completer(text: str, state: int):
        if not readline.get_line_buffer().startswith("/"):
            return None
        opts = [c for c in list(COMMANDS) + ["/quit"] if c.startswith(text)]
        return opts[state] if state < len(opts) else None

    readline.set_completer(completer)
    readline.set_completer_delims(" \t\n")
    readline.parse_and_bind("tab: complete")
    hist = Path.home() / ".openclient_history"
    try:
        readline.read_history_file(hist)
    except OSError:
        pass
    import atexit
    atexit.register(lambda: _save_history(hist))


def _save_history(path: Path) -> None:
    try:
        import readline
        readline.set_history_length(1000)
        readline.write_history_file(path)
    except Exception:
        pass


def repl(s: Session) -> int:
    _setup_completion()
    ui.banner(__version__, str(s.agent.cwd), s.agent.spec["name"], s.agent.spec["model"], s.agent.mode)
    spec = s.agent.spec
    if not spec.get("api_key") and spec.get("env"):
        ui.warn(f"{spec['name']} için API anahtarı yok. /connect yaz veya {spec['env']} ortam değişkenini ayarla.")
        ui.out()
    armed = False
    while True:
        try:
            text = ui.read_input(s.agent.mode)
        except EOFError:
            ui.out()
            break
        except KeyboardInterrupt:
            ui.out()
            if armed:
                break
            ui.out(ui.style("  Çıkmak için tekrar Ctrl+C veya /exit", "muted"))
            armed = True
            continue
        armed = False
        if not text:
            continue
        if text.startswith(("/", "!")):
            try:
                forward = handle_command(s, text)
            except EOFError:
                break
            if not forward:
                continue
            text = forward
        s.agent.run(text)
        s.save()
    s.save()
    ui.out(ui.style("  Görüşürüz!", "muted"))
    return 0


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    ui.init_color(False if args.no_color else None)
    cfg = Config()
    spec = cfg.resolve(args.provider, args.model, args.base_url)
    agent = Agent(make_provider(spec), spec, Path.cwd(), auto_approve=args.yes,
                  interactive=sys.stdin.isatty())
    if args.plan:
        agent.mode = "plan"
    s = Session(cfg, agent)
    if args.cont:
        recent = list_sessions(1)
        if recent:
            loaded = load_session(recent[0][0])
            if loaded:
                agent.history, _ = loaded
                s.id = recent[0][0]

    if args.prompt:
        if not spec.get("api_key") and spec.get("env"):
            ui.error(f"{spec['name']} için API anahtarı yok ({spec['env']}).")
            return 1
        try:
            agent.run(" ".join(args.prompt))
        except KeyboardInterrupt:
            return 130
        s.save()
        return 0
    try:
        return repl(s)
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
