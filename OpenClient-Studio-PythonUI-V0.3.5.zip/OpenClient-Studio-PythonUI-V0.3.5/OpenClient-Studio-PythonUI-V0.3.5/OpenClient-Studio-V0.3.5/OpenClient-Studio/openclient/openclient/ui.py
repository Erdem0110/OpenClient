"""Terminal arayüzü: OpenCode temalı renkler, logo, markdown akışı, spinner.

Yalnızca standart kütüphane kullanır. Windows 10/11 terminalinde ANSI/truecolor
desteği otomatik açılır.
"""

from __future__ import annotations

import difflib
import os
import re
import shutil
import sys
import threading
import time

try:  # Windows'ta yoktur
    import readline  # noqa: F401

    HAS_READLINE = True
except Exception:  # pragma: no cover
    readline = None  # type: ignore
    HAS_READLINE = False


# --------------------------------------------------------------------------
# Renk altyapısı
# --------------------------------------------------------------------------

# OpenCode "opencode" teması (koyu)
PALETTE = {
    "bg": "0a0a0a",
    "panel": "141414",
    "element": "1e1e1e",
    "border": "484848",
    "text": "eeeeee",
    "muted": "808080",
    "primary": "fab283",  # şeftali - OpenCode'un imza rengi
    "secondary": "5c9cf5",
    "accent": "9d7cd8",
    "success": "7fd88f",
    "error": "e06c75",
    "warning": "f5a742",
    "info": "56b6c2",
    "add_bg": "1c3a26",
    "del_bg": "3d1f24",
}

_state = {"color": None, "truecolor": True}


def enable_windows_vt() -> None:
    if os.name != "nt":
        return
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except Exception:
        os.system("")  # eski hile: VT modunu açar
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
        sys.stderr.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except Exception:
        pass


def init_color(force: bool | None = None) -> None:
    enable_windows_vt()
    if force is not None:
        _state["color"] = force
    elif os.environ.get("NO_COLOR"):
        _state["color"] = False
    else:
        _state["color"] = bool(sys.stdout.isatty() or os.environ.get("FORCE_COLOR"))
    ct = os.environ.get("COLORTERM", "").lower()
    _state["truecolor"] = os.name == "nt" or ct in ("truecolor", "24bit")


def color_enabled() -> bool:
    if _state["color"] is None:
        init_color()
    return bool(_state["color"])


def _rgb(hexcolor: str) -> tuple[int, int, int]:
    return int(hexcolor[0:2], 16), int(hexcolor[2:4], 16), int(hexcolor[4:6], 16)


def _code(hexcolor: str, bg: bool = False) -> str:
    r, g, b = _rgb(hexcolor)
    if _state["truecolor"]:
        return f"\x1b[{48 if bg else 38};2;{r};{g};{b}m"
    idx = 16 + 36 * round(r / 255 * 5) + 6 * round(g / 255 * 5) + round(b / 255 * 5)
    return f"\x1b[{48 if bg else 38};5;{idx}m"


def style(text: str, fg: str | None = None, bg: str | None = None, bold: bool = False,
          dim: bool = False, italic: bool = False) -> str:
    if not color_enabled():
        return text
    pre = ""
    if bold:
        pre += "\x1b[1m"
    if dim:
        pre += "\x1b[2m"
    if italic:
        pre += "\x1b[3m"
    if fg:
        pre += _code(PALETTE.get(fg, fg))
    if bg:
        pre += _code(PALETTE.get(bg, bg), bg=True)
    return f"{pre}{text}\x1b[0m" if pre else text


def strip_ansi(s: str) -> str:
    return re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", s)


def out(text: str = "", end: str = "\n") -> None:
    sys.stdout.write(text + end)
    sys.stdout.flush()


def term_width() -> int:
    return max(40, shutil.get_terminal_size((100, 24)).columns)


# --------------------------------------------------------------------------
# Logo ve başlık
# --------------------------------------------------------------------------

_FONT = {
    "o": ["█▀▀█", "█  █", "▀▀▀▀"],
    "p": ["█▀▀█", "█▀▀▀", "▀   "],
    "e": ["█▀▀█", "█▀▀▀", "▀▀▀▀"],
    "n": ["█▀▀█", "█  █", "▀  ▀"],
    "c": ["█▀▀▀", "█   ", "▀▀▀▀"],
    "l": ["█   ", "█   ", "▀▀▀▀"],
    "i": ["▄ ", "█ ", "█ "],
    "t": [" █ ", "▀█▀", " ▀▀"],
}


def _word(word: str) -> list[str]:
    rows = ["", "", ""]
    for ch in word:
        glyph = _FONT[ch]
        for i in range(3):
            rows[i] += glyph[i] + " "
    return rows


def logo() -> list[str]:
    left, right = _word("open"), _word("client")
    lines = []
    for a, b in zip(left, right):
        lines.append(style(a, "muted") + " " + style(b, "text", bold=True))
    return lines


def banner(version: str, cwd: str, provider: str, model: str, agent: str) -> None:
    out()
    for line in logo():
        out("  " + line)
    out()
    out("  " + style(f"v{version}", "muted") + style("  ·  ", "border") + style(cwd, "muted"))
    out("  " + style("model ", "muted") + style(model, "text") + style(f" ({provider})", "muted")
        + style("   agent ", "muted") + style(agent, "primary", bold=True))
    out("  " + style("/help", "primary") + style(" komutlar  ·  ", "muted")
        + style("/connect", "primary") + style(" API anahtarı  ·  ", "muted")
        + style("/plan", "primary") + style(" salt-okunur mod", "muted"))
    out()


# --------------------------------------------------------------------------
# Prompt
# --------------------------------------------------------------------------

def _rl(s: str) -> str:
    """readline'a görünmez karakterleri bildir (ANSI)."""
    if HAS_READLINE and color_enabled():
        return re.sub(r"(\x1b\[[0-9;]*m)", "\x01\\1\x02", s)
    return s


def agent_color(agent: str) -> str:
    return "primary" if agent == "build" else "accent"


def read_input(agent: str) -> str:
    """OpenCode tarzı sol çubuklu giriş kutusu. Satır sonu '\\' ile çok satırlı girdi."""
    bar = style("┃", agent_color(agent))
    out(bar)
    lines: list[str] = []
    prompt = f"{bar} " + style("❯ ", agent_color(agent), bold=True)
    cont = f"{bar}   "
    while True:
        line = input(_rl(prompt if not lines else cont))
        if line.endswith("\\"):
            lines.append(line[:-1])
            continue
        lines.append(line)
        break
    return "\n".join(lines).strip()


def footer(agent: str, model: str, seconds: float, tokens_in: int, tokens_out: int) -> None:
    parts = [style("▣ ", agent_color(agent)), style(agent.capitalize(), "text"),
             style(f" · {model} · {seconds:.1f}s", "muted")]
    if tokens_in or tokens_out:
        parts.append(style(f" · {tokens_in:,}↑ {tokens_out:,}↓", "muted"))
    out()
    out("".join(parts))
    out()


# --------------------------------------------------------------------------
# Spinner
# --------------------------------------------------------------------------

class Spinner:
    FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

    def __init__(self, label: str = "Düşünüyor") -> None:
        self.label = label
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._active = False

    def start(self) -> None:
        if not (sys.stdout.isatty() and color_enabled()) or self._active:
            return
        self._active = True
        self._stop.clear()
        sys.stdout.write("\x1b[?25l")
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        i = 0
        t0 = time.time()
        while not self._stop.is_set():
            frame = self.FRAMES[i % len(self.FRAMES)]
            elapsed = int(time.time() - t0)
            sys.stdout.write(
                "\r\x1b[2K" + style(frame, "primary") + " " + style(f"{self.label}… {elapsed}s", "muted"))
            sys.stdout.flush()
            i += 1
            self._stop.wait(0.08)

    def stop(self) -> None:
        if not self._active:
            return
        self._stop.set()
        if self._thread:
            self._thread.join()
        sys.stdout.write("\r\x1b[2K\x1b[?25h")
        sys.stdout.flush()
        self._active = False


# --------------------------------------------------------------------------
# Markdown akışı (satır tamponlu)
# --------------------------------------------------------------------------

def inline_md(line: str) -> str:
    if not color_enabled():
        return re.sub(r"\*\*(.+?)\*\*", r"\1", re.sub(r"`([^`\n]+)`", r"\1", line))
    parts = re.split(r"(`[^`\n]+`)", line)
    res = []
    for p in parts:
        if len(p) > 2 and p.startswith("`") and p.endswith("`"):
            res.append(style(p[1:-1], "accent"))
        else:
            p = re.sub(r"\*\*(.+?)\*\*", lambda m: "\x1b[1m" + m.group(1) + "\x1b[22m", p)
            p = re.sub(r"(?<![\w*])\*(?!\s)([^*\n]+?)\*(?![\w*])",
                       lambda m: "\x1b[3m" + m.group(1) + "\x1b[23m", p)
            res.append(p)
    return "".join(res)


class MarkdownStream:
    """Gelen metin parçalarını satır satır biçimlendirip yazar."""

    def __init__(self, on_first_output=None) -> None:
        self.buf = ""
        self.in_code = False
        self.on_first_output = on_first_output
        self.started = False

    def _emit(self, s: str) -> None:
        if not self.started:
            self.started = True
            if self.on_first_output:
                self.on_first_output()
        sys.stdout.write(s + "\n")
        sys.stdout.flush()

    def feed(self, text: str) -> None:
        self.buf += text
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            self._line(line)

    def finish(self) -> None:
        if self.buf:
            self._line(self.buf)
            self.buf = ""
        if self.in_code:
            self.in_code = False

    def _line(self, line: str) -> None:
        stripped = line.strip()
        if stripped.startswith("```"):
            if not self.in_code:
                self.in_code = True
                lang = stripped[3:].strip()
                if lang:
                    self._emit(style(f" {lang} ".ljust(term_width() - 2), "muted", bg="element"))
                else:
                    self._emit(style(" " * (term_width() - 2), None, bg="element"))
            else:
                self.in_code = False
                self._emit(style(" " * (term_width() - 2), None, bg="element"))
            return
        if self.in_code:
            pad = max(0, term_width() - 3 - len(line.expandtabs(4)))
            self._emit(style(" " + line.expandtabs(4) + " " * pad, "text", bg="element"))
            return
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            self._emit(style(m.group(2), "primary", bold=True))
            return
        m = re.match(r"^(\s*)[-*+]\s+(.*)$", line)
        if m:
            self._emit(m.group(1) + style("•", "primary") + " " + inline_md(m.group(2)))
            return
        m = re.match(r"^(\s*)(\d+)\.\s+(.*)$", line)
        if m:
            self._emit(m.group(1) + style(m.group(2) + ".", "primary") + " " + inline_md(m.group(3)))
            return
        if stripped.startswith(">"):
            self._emit(style("▎", "border") + " " + style(stripped.lstrip("> "), "muted", italic=True))
            return
        if re.match(r"^\s*([-*_])\1{2,}\s*$", line):
            self._emit(style("─" * min(60, term_width() - 4), "border"))
            return
        self._emit(inline_md(line))


# --------------------------------------------------------------------------
# Araç çıktıları
# --------------------------------------------------------------------------

TOOL_ICONS = {
    "read": "→", "write": "←", "edit": "←", "bash": "$", "glob": "✱",
    "grep": "✱", "ls": "→", "webfetch": "%",
}


def tool_header(name: str, summary: str, status: str = "run") -> None:
    icon = TOOL_ICONS.get(name, "⚙")
    col = "secondary" if status == "run" else ("error" if status == "error" else "success")
    out(style(f"  {icon} ", col) + style(name.capitalize() + " ", "text", bold=True) + style(summary, "muted"))


def tool_output(text: str, max_lines: int = 8, is_error: bool = False) -> None:
    if not text.strip():
        return
    lines = text.rstrip("\n").split("\n")
    shown = lines[:max_lines]
    col = "error" if is_error else "muted"
    w = term_width() - 6
    for ln in shown:
        ln = ln.expandtabs(4)
        if len(ln) > w:
            ln = ln[: w - 1] + "…"
        out(style("  │ ", "border") + style(ln, col))
    if len(lines) > max_lines:
        out(style("  │ ", "border") + style(f"… {len(lines) - max_lines} satır daha", "muted", italic=True))


def render_diff(old: str, new: str, path: str, max_lines: int = 40) -> str:
    diff = list(difflib.unified_diff(old.splitlines(), new.splitlines(), f"a/{path}", f"b/{path}",
                                     lineterm="", n=2))
    return "\n".join(diff[:max_lines] + (["…"] if len(diff) > max_lines else []))


def print_diff(diff_text: str) -> None:
    w = term_width() - 6
    for ln in diff_text.split("\n"):
        if ln.startswith(("+++", "---")):
            out(style("  │ ", "border") + style(ln, "muted"))
        elif ln.startswith("+"):
            out(style("  │ ", "border") + style(ln[:w].ljust(w), "success", bg="add_bg"))
        elif ln.startswith("-"):
            out(style("  │ ", "border") + style(ln[:w].ljust(w), "error", bg="del_bg"))
        elif ln.startswith("@@"):
            out(style("  │ ", "border") + style(ln[:w], "info"))
        else:
            out(style("  │ ", "border") + style(ln[:w], "muted"))


def info(msg: str) -> None:
    out(style("  ● ", "info") + msg)


def warn(msg: str) -> None:
    out(style("  ▲ ", "warning") + style(msg, "warning"))


def error(msg: str) -> None:
    out(style("  ✗ ", "error") + style(msg, "error"))


def ask_permission(tool: str, summary: str) -> str:
    """'once' | 'always' | 'deny'"""
    out(style("  △ ", "warning") + style("İzin gerekli: ", "warning", bold=True)
        + style(tool, "text", bold=True) + " " + style(summary, "muted"))
    prompt = ("  " + style("[y]", "success") + style(" bir kez  ", "muted")
              + style("[a]", "primary") + style(" oturum boyunca  ", "muted")
              + style("[n]", "error") + style(" reddet ", "muted") + "› ")
    while True:
        try:
            ans = input(_rl(prompt)).strip().lower()
        except (EOFError, KeyboardInterrupt):
            out()
            return "deny"
        if ans in ("y", "yes", "e", "evet", ""):
            return "once"
        if ans in ("a", "always", "h"):
            return "always"
        if ans in ("n", "no", "hayır", "hayir"):
            return "deny"
