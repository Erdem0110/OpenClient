"""Yapılandırma, sağlayıcı ön ayarları ve oturum kaydı."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

PRESETS: dict[str, dict] = {
    "anthropic": {
        "label": "Anthropic",
        "type": "anthropic",
        "base_url": "https://api.anthropic.com",
        "env": "ANTHROPIC_API_KEY",
        "model": "claude-sonnet-5-5",
    },
    "openai": {
        "label": "OpenAI",
        "type": "openai",
        "base_url": "https://api.openai.com/v1",
        "env": "OPENAI_API_KEY",
        "model": "gpt-4.1",
    },
    "openrouter": {
        "label": "OpenRouter",
        "type": "openai",
        "base_url": "https://openrouter.ai/api/v1",
        "env": "OPENROUTER_API_KEY",
        "model": "anthropic/claude-sonnet-4.5",
    },
    "ollama": {
        "label": "Ollama (yerel)",
        "type": "openai",
        "base_url": "http://localhost:11434/v1",
        "env": None,
        "model": "qwen2.5-coder",
    },
    "custom": {
        "label": "Özel (OpenAI uyumlu)",
        "type": "openai",
        "base_url": "http://localhost:8080/v1",
        "env": "OPENCLIENT_API_KEY",
        "model": "default",
    },
}


def config_dir() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "openclient"


def data_dir() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "openclient"


class Config:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or (config_dir() / "config.json")
        self.data: dict = {"provider": "anthropic", "model": None, "providers": {}}
        self.load()

    def load(self) -> None:
        try:
            self.data.update(json.loads(self.path.read_text(encoding="utf-8")))
        except FileNotFoundError:
            pass
        except (OSError, json.JSONDecodeError):
            pass

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
        try:
            os.chmod(self.path, 0o600)  # içinde API anahtarı olabilir
        except OSError:
            pass

    # -- sağlayıcı çözümleme ------------------------------------------------
    def provider_names(self) -> list[str]:
        return list(dict.fromkeys(list(PRESETS) + list(self.data.get("providers", {}))))

    def resolve(self, name: str | None = None, model: str | None = None,
                base_url: str | None = None) -> dict:
        name = name or self.data.get("provider") or "anthropic"
        spec = dict(PRESETS.get(name, PRESETS["custom"]))
        spec.update(self.data.get("providers", {}).get(name, {}))
        spec["name"] = name
        if base_url:
            spec["base_url"] = base_url
        if model:
            spec["model"] = model
        elif self.data.get("model") and name == self.data.get("provider"):
            spec["model"] = self.data["model"]
        key = spec.get("api_key")
        if not key and spec.get("env"):
            key = os.environ.get(spec["env"])
        spec["api_key"] = key
        return spec

    def set_key(self, provider: str, key: str) -> None:
        self.data.setdefault("providers", {}).setdefault(provider, {})["api_key"] = key
        self.save()

    def set_default(self, provider: str, model: str | None) -> None:
        self.data["provider"] = provider
        self.data["model"] = model
        self.save()


# -- oturumlar --------------------------------------------------------------

def sessions_dir() -> Path:
    d = data_dir() / "sessions"
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_session(session_id: str, history: list, meta: dict) -> None:
    try:
        (sessions_dir() / f"{session_id}.json").write_text(
            json.dumps({"meta": meta, "history": history}, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def list_sessions(limit: int = 10) -> list[tuple[str, dict]]:
    items = []
    for p in sorted(sessions_dir().glob("*.json"), reverse=True)[:limit]:
        try:
            items.append((p.stem, json.loads(p.read_text(encoding="utf-8")).get("meta", {})))
        except (OSError, json.JSONDecodeError):
            continue
    return items


def load_session(session_id: str) -> tuple[list, dict] | None:
    try:
        d = json.loads((sessions_dir() / f"{session_id}.json").read_text(encoding="utf-8"))
        return d["history"], d.get("meta", {})
    except (OSError, json.JSONDecodeError, KeyError):
        return None


def new_session_id() -> str:
    return time.strftime("%Y%m%d-%H%M%S")
