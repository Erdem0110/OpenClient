"""OpenClient - terminalde çalışan, OpenCode tarzı yapay zekâ kodlama asistanı."""

__version__ = "0.1.0"
