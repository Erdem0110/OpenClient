"""OpenClient masaüstü uygulaması: yerel sunucu + uygulama penceresi.

Aynı ajan çekirdeği (agent/providers/tools) kullanılır; ön yüz bir tarayıcı
motorunda (Edge/Chrome "uygulama modu") açılan yerel arayüzdür. Sunucu yalnızca
127.0.0.1'e bağlanır ve rastgele bir jetonla korunur.
"""

from __future__ import annotations

import argparse
import http.cookies
import json
import os
import secrets
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import __version__, tools
from .agent import Agent
from .cli import INIT_PROMPT, Session
from .config import PRESETS, Config, config_dir, data_dir, list_sessions, load_session, save_session
from .frontend import Frontend
from .providers import make_provider

WEB_DIR = Path(__file__).resolve().parent / "web_ui"
STATIC = {"/app.css": "text/css; charset=utf-8", "/app.js": "text/javascript; charset=utf-8"}
NO_WINDOW = 0x08000000 if os.name == "nt" else 0


# --------------------------------------------------------------------------
# Yardımcılar
# --------------------------------------------------------------------------

def git_branch(cwd: Path) -> str | None:
    try:
        r = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=str(cwd), capture_output=True,
                           text=True, timeout=2, creationflags=NO_WINDOW)
        return r.stdout.strip() or None if r.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


def pick_folder() -> str | None:
    """İşletim sisteminin yerel klasör seçme penceresi (ek kurulum gerektirmez)."""
    try:
        if os.name == "nt":
            ps = ("Add-Type -AssemblyName System.Windows.Forms; "
                  "$f = New-Object System.Windows.Forms.FolderBrowserDialog; "
                  "$f.Description = 'Proje klasörünü seç'; "
                  "if ($f.ShowDialog() -eq 'OK') { [Console]::OutputEncoding = [Text.Encoding]::UTF8; $f.SelectedPath }")
            r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], capture_output=True,
                               text=True, encoding="utf-8", timeout=600, creationflags=NO_WINDOW)
        elif sys.platform == "darwin":
            r = subprocess.run(["osascript", "-e", 'POSIX path of (choose folder with prompt "Proje klasörünü seç")'],
                               capture_output=True, text=True, timeout=600)
        elif shutil.which("zenity"):
            r = subprocess.run(["zenity", "--file-selection", "--directory"], capture_output=True, text=True,
                               timeout=600)
        elif shutil.which("kdialog"):
            r = subprocess.run(["kdialog", "--getexistingdirectory", str(Path.home())], capture_output=True,
                               text=True, timeout=600)
        else:
            return None
        path = r.stdout.strip()
        return path if path and Path(path).is_dir() else None
    except (OSError, subprocess.SubprocessError):
        return None


def list_models(spec: dict) -> list[str]:
    """Sağlayıcının sunduğu model adlarını getirir (Ollama'da yüklü modeller dahil)."""
    base = spec["base_url"].rstrip("/")
    headers = {}
    if spec.get("type") == "anthropic":
        url = base + "/v1/models?limit=100"
        if spec.get("api_key"):
            headers = {"x-api-key": spec["api_key"], "anthropic-version": "2023-06-01"}
        else:
            return []
    else:
        url = base + "/models"
        if spec.get("api_key"):
            headers["authorization"] = f"Bearer {spec['api_key']}"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=4) as r:
            data = json.loads(r.read().decode("utf-8"))
        ids = [m.get("id") for m in data.get("data", []) if m.get("id")]
        return sorted(ids)
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError):
        return []


def search_files(cwd: Path, query: str, limit: int = 12) -> list[str]:
    q = query.lower().replace("\\", "/")
    found = []
    for i, f in enumerate(tools._walk(cwd)):
        if i > 8000:
            break
        rel = f.relative_to(cwd).as_posix()
        if q in rel.lower():
            found.append(rel)
    found.sort(key=lambda r: (len(r), r))
    return found[:limit]


def find_app_browser() -> str | None:
    cands: list[str] = []
    if os.name == "nt":
        for var in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
            base = os.environ.get(var)
            if base:
                cands += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                          os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"),
                          os.path.join(base, "BraveSoftware", "Brave-Browser", "Application", "brave.exe")]
    elif sys.platform == "darwin":
        cands += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                  "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"]
    else:
        for n in ("google-chrome", "google-chrome-stable", "microsoft-edge", "chromium", "chromium-browser", "brave-browser"):
            p = shutil.which(n)
            if p:
                cands.append(p)
    return next((c for c in cands if os.path.isfile(c)), None)


def open_window(url: str) -> bool:
    exe = find_app_browser()
    if exe:
        profile = data_dir() / "window-profile"
        profile.mkdir(parents=True, exist_ok=True)
        try:
            subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={profile}", "--window-size=1280,860",
                              "--no-first-run", "--no-default-browser-check", "--disable-features=Translate"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except OSError:
            pass
    return webbrowser.open(url)


# --------------------------------------------------------------------------
# Ön yüz: ajan olaylarını arayüze iletir
# --------------------------------------------------------------------------

class WebFrontend(Frontend):
    def __init__(self, app: "App") -> None:
        self.app = app
        self.pending: dict[str, dict] = {}
        self._text_start: int | None = None

    def begin_thinking(self, label: str = "Düşünüyor") -> None:
        self.app.emit("thinking", on=True, label=label)

    def text(self, chunk: str) -> None:
        idx = self.app.emit("text", delta=chunk)
        if self._text_start is None:
            self._text_start = idx

    def text_end(self) -> None:
        self.app.compact_text(self._text_start)
        self._text_start = None
        self.app.emit("text_end")

    def tool_start(self, name: str, summary: str, status: str = "run") -> None:
        self.app.emit("tool", name=name, summary=summary, status=status)

    def tool_output(self, text: str, is_error: bool = False) -> None:
        self.app.emit("tool_out", text=text[:6000], error=is_error)

    def tool_diff(self, diff: str) -> None:
        self.app.emit("tool_diff", text=diff)

    def tool_note(self, text: str, level: str = "muted") -> None:
        self.app.emit("tool_note", text=text, level=level)

    def show_preview(self, preview: dict | None) -> None:
        if preview:
            self.app.emit("preview", **preview)

    def notice(self, level: str, text: str) -> None:
        self.app.emit("notice", level=level, text=text)

    def footer(self, agent: str, model: str, seconds: float, tin: int, tout: int) -> None:
        self.app.emit("footer", agent=agent, model=model, seconds=round(seconds, 1), tin=tin, tout=tout)

    def ask_permission(self, tool: str, summary: str, preview: dict | None) -> str:
        pid = uuid.uuid4().hex[:8]
        slot = {"event": threading.Event(), "choice": "deny"}
        self.pending[pid] = slot
        self.app.emit("permission", pid=pid, tool=tool, summary=summary, preview=preview)
        while not slot["event"].wait(0.25):
            if self.app.agent.cancel.is_set():
                slot["choice"] = "deny"
                break
        self.pending.pop(pid, None)
        self.app.emit("permission_done", pid=pid, choice=slot["choice"])
        return slot["choice"]

    def answer(self, pid: str, choice: str) -> bool:
        slot = self.pending.get(pid)
        if not slot or choice not in ("once", "always", "deny"):
            return False
        slot["choice"] = choice
        slot["event"].set()
        return True


# --------------------------------------------------------------------------
# Uygulama durumu
# --------------------------------------------------------------------------

class App:
    def __init__(self, cfg: Config, spec: dict, cwd: Path | None, auto_approve: bool = False,
                 keep_alive: bool = False) -> None:
        self.cfg = cfg
        self.token = secrets.token_urlsafe(24)
        self.port = 0
        self.keep_alive = keep_alive
        self.events: list[dict] = []
        self.cond = threading.Condition()
        self._seq = 0
        self.fe = WebFrontend(self)
        self.cwd_set = cwd is not None
        self.agent = Agent(make_provider(spec), spec, cwd or Path.home(), auto_approve=auto_approve,
                           interactive=True, frontend=self.fe)
        self.session = Session(cfg, self.agent)
        self.busy = False
        self._run_lock = threading.Lock()
        self.started = time.time()
        self.last_ping = 0.0
        self.bye_at = 0.0
        self.connected = False
        self.server: ThreadingHTTPServer | None = None
        self.done = threading.Event()

    # -- olay günlüğü -------------------------------------------------------
    def emit(self, type_: str, **data) -> int:
        with self.cond:
            self._seq += 1
            # "id" ve "type" olay zarfına ait; data içindeki aynı adlı alanları (ör.
            # izin isteğinin kendi 'id'si) ezmesinler diye en son biz yazıyoruz.
            event = {**data, "id": self._seq, "type": type_}
            self.events.append(event)
            self.cond.notify_all()
            return self._seq

    def compact_text(self, start_id: int | None) -> None:
        """Art arda gelen text parçalarını tek 'assistant' olayına indirger (sayfa yenilemede hızlı tekrar)."""
        if start_id is None:
            return
        with self.cond:
            idxs = [i for i, e in enumerate(self.events) if e["id"] >= start_id and e["type"] == "text"]
            if not idxs:
                return
            full = "".join(self.events[i]["delta"] for i in idxs)
            last = self.events[idxs[-1]]["id"]
            self.events = [e for i, e in enumerate(self.events) if i not in idxs[:-1]]
            for e in self.events:
                if e["id"] == last:
                    e.clear()
                    e.update({"id": last, "type": "assistant", "text": full, "live": True})

    def reset_events(self) -> None:
        with self.cond:
            self.events = []
            self.cond.notify_all()
        self.emit("reset")

    # -- durum --------------------------------------------------------------
    def providers_info(self) -> list[dict]:
        res = []
        for name in self.cfg.provider_names():
            s = self.cfg.resolve(name)
            res.append({"name": name, "label": s.get("label", name), "type": s["type"], "model": s["model"],
                        "base_url": s["base_url"], "env": s.get("env"),
                        "ready": bool(s.get("api_key")) or not s.get("env"),
                        "has_key": bool(s.get("api_key"))})
        return res

    def state(self) -> dict:
        cwd = self.agent.cwd
        return {
            "version": __version__, "cwd": str(cwd) if self.cwd_set else None,
            "folder": cwd.name or str(cwd), "branch": git_branch(cwd) if self.cwd_set else None,
            "provider": self.agent.spec["name"], "model": self.agent.spec["model"], "mode": self.agent.mode,
            "auto_approve": self.agent.auto_approve, "busy": self.busy, "session": self.session.id,
            "providers": self.providers_info(), "recent": self.cfg.data.get("recent_dirs", []),
            "platform": sys.platform, "ui": self.cfg.data.get("ui", {}),
        }

    def push_state(self) -> None:
        self.emit("state", state=self.state())

    # -- tur çalıştırma -----------------------------------------------------
    def run_async(self, fn) -> bool:
        with self._run_lock:
            if self.busy:
                return False
            self.busy = True
        self.agent.cancel.clear()
        self.emit("status", busy=True)

        def worker() -> None:
            try:
                fn()
            except Exception as e:  # noqa: BLE001
                self.fe.text_end()
                self.emit("notice", level="error", text=f"Beklenmeyen hata: {type(e).__name__}: {e}")
            finally:
                self.session.save()
                self.busy = False
                self.emit("status", busy=False)
                self.push_state()

        threading.Thread(target=worker, daemon=True).start()
        return True

    def send(self, text: str) -> tuple[bool, str]:
        if not self.cwd_set:
            return False, "Önce bir proje klasörü seç."
        if self.busy:
            return False, "Ajan şu an çalışıyor."
        self.emit("user", text=text)
        self.run_async(lambda: self.agent.run(text))
        return True, ""

    def cancel(self) -> None:
        self.agent.cancel.set()
        for pid in list(self.fe.pending):
            self.fe.answer(pid, "deny")

    # -- klasör / oturum ----------------------------------------------------
    def set_cwd(self, path: str) -> tuple[bool, str]:
        if self.busy:
            return False, "Ajan çalışırken klasör değiştirilemez."
        p = Path(os.path.expanduser(path.strip().strip('"')))
        if not p.is_dir():
            return False, f"Klasör bulunamadı: {p}"
        p = p.resolve()
        self.agent.cwd = p
        self.cwd_set = True
        self.agent.always.clear()
        self.session.reset()
        recent = [str(p)] + [d for d in self.cfg.data.get("recent_dirs", []) if d != str(p)]
        self.cfg.data["recent_dirs"] = recent[:8]
        self.cfg.save()
        self.reset_events()
        self.push_state()
        return True, ""

    def sessions(self) -> list[dict]:
        out = []
        for sid, meta in list_sessions(40):
            out.append({"id": sid, "title": meta.get("title") or "(başlıksız)", "cwd": meta.get("cwd", ""),
                        "model": meta.get("model", "")})
        return out

    def resume(self, sid: str) -> tuple[bool, str]:
        if self.busy:
            return False, "Ajan çalışırken oturum değiştirilemez."
        loaded = load_session(sid)
        if not loaded:
            return False, "Oturum bulunamadı."
        history, meta = loaded
        cwd = meta.get("cwd")
        if cwd and Path(cwd).is_dir():
            self.agent.cwd = Path(cwd)
            self.cwd_set = True
        self.agent.history = history
        self.session.id = sid
        self.reset_events()
        for ev in history_to_events(history):
            self.emit(ev.pop("type"), **ev)
        self.push_state()
        return True, ""

    def delete_session(self, sid: str) -> bool:
        from .config import sessions_dir
        p = sessions_dir() / f"{Path(sid).name}.json"
        try:
            p.unlink()
            return True
        except OSError:
            return False

    # -- ayarlar ------------------------------------------------------------
    def connect(self, body: dict) -> tuple[bool, str]:
        name = body.get("provider")
        if name not in self.cfg.provider_names():
            return False, "Bilinmeyen sağlayıcı."
        prov = self.cfg.data.setdefault("providers", {}).setdefault(name, {})
        if body.get("api_key"):
            prov["api_key"] = body["api_key"].strip()
        if body.get("clear_key"):
            prov.pop("api_key", None)
        if body.get("base_url"):
            prov["base_url"] = body["base_url"].strip()
        model = (body.get("model") or "").strip() or None
        if model:
            prov["model"] = model
        self.cfg.save()
        if body.get("activate", True):
            self.cfg.set_default(name, model)
            self.session.switch(self.cfg.resolve(name, model=model))
        self.push_state()
        return True, ""

    def set_mode(self, mode: str) -> None:
        if mode in ("build", "plan"):
            self.agent.mode = mode
            self.push_state()

    # -- komutlar -----------------------------------------------------------
    def command(self, text: str) -> str | None:
        """Slash/! komutlarını işler. Ajana iletilecek metin dönerse onu döndürür."""
        if text.startswith("!"):
            cmd = text[1:].strip()
            if not self.cwd_set:
                self.emit("notice", level="warn", text="Önce bir proje klasörü seç.")
                return None
            self.emit("user", text=text)

            def shell() -> None:
                self.fe.tool_start("bash", cmd)
                res = tools.BY_NAME["bash"].run({"command": cmd}, self.agent.cwd)
                self.fe.tool_output(res.output, res.is_error)
            self.run_async(shell)
            return None
        name, _, arg = text.partition(" ")
        name = name.lower()
        a = self.agent
        if name in ("/plan", "/build"):
            self.set_mode(name[1:])
        elif name in ("/new", "/clear"):
            if not self.busy:
                self.session.reset()
                self.reset_events()
                self.push_state()
        elif name == "/compact":
            self.run_async(a.compact)
        elif name == "/yolo":
            a.auto_approve = not a.auto_approve
            self.emit("notice", level="warn" if a.auto_approve else "info",
                      text="Tüm izinler otomatik onaylanacak." if a.auto_approve else "İzin soruları geri açıldı.")
            self.push_state()
        elif name == "/model":
            parts = arg.split()
            if parts:
                prov, model = (parts[0], parts[1]) if len(parts) > 1 and parts[0] in self.cfg.provider_names() \
                    else (a.spec["name"], parts[0])
                self.connect({"provider": prov, "model": model})
                self.emit("notice", level="info", text=f"Model: {prov} / {model}")
        elif name == "/init":
            return INIT_PROMPT
        elif name == "/resume" and arg.strip():
            ok, msg = self.resume(arg.strip())
            if not ok:
                self.emit("notice", level="error", text=msg)
        else:
            self.emit("notice", level="error", text=f"Bilinmeyen komut: {name}")
        return None


def history_to_events(history: list[dict]) -> list[dict]:
    events: list[dict] = []
    for m in history:
        if m["role"] == "user":
            events.append({"type": "user", "text": m["content"]})
        elif m["role"] == "assistant":
            if m.get("content"):
                events.append({"type": "assistant", "text": m["content"]})
            for tc in m.get("tool_calls", []):
                t = tools.BY_NAME.get(tc["name"])
                events.append({"type": "tool", "name": tc["name"], "status": "done",
                               "summary": t.summary(tc["args"]) if t else ""})
        elif m["role"] == "tool" and m.get("content"):
            events.append({"type": "tool_out", "text": m["content"][:1500], "error": bool(m.get("is_error"))})
    return events


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------

def make_handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a) -> None:  # sessiz
            pass

        # -- güvenlik ---
        def _host_ok(self) -> bool:
            return self.headers.get("Host", "") in (f"127.0.0.1:{app.port}", f"localhost:{app.port}")

        def _origin_ok(self) -> bool:
            o = self.headers.get("Origin")
            return o is None or o in (f"http://127.0.0.1:{app.port}", f"http://localhost:{app.port}")

        def _authed(self) -> bool:
            c = http.cookies.SimpleCookie(self.headers.get("Cookie", ""))
            m = c.get("oc_token")
            return bool(m) and secrets.compare_digest(m.value, app.token)

        def _deny(self, code: int = 403, msg: str = "Yetkisiz") -> None:
            self._send(code, msg.encode("utf-8"), "text/plain; charset=utf-8")

        def _send(self, code: int, body: bytes, ctype: str, headers: dict | None = None) -> None:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _json(self, obj, code: int = 200) -> None:
            self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

        # -- GET ---
        def do_GET(self) -> None:
            if not self._host_ok():
                return self._deny()
            path, _, query = self.path.partition("?")
            params = dict(p.split("=", 1) for p in query.split("&") if "=" in p)
            from urllib.parse import unquote
            params = {k: unquote(v.replace("+", " ")) for k, v in params.items()}

            if path == "/":
                if params.get("t") and secrets.compare_digest(params["t"], app.token):
                    return self._send(302, b"", "text/plain", {
                        "Location": "/", "Set-Cookie": f"oc_token={app.token}; HttpOnly; SameSite=Strict; Path=/"})
                if not self._authed():
                    return self._deny(403, "Bu sayfa yalnızca OpenClient penceresinden açılabilir.")
                return self._send(200, (WEB_DIR / "index.html").read_bytes(), "text/html; charset=utf-8")
            if not self._authed():
                return self._deny()
            if path in STATIC:
                ctype = STATIC[path]
                return self._send(200, (WEB_DIR / path.lstrip("/")).read_bytes(), ctype)
            if path == "/api/state":
                return self._json(app.state())
            if path == "/api/ping":
                app.last_ping, app.connected, app.bye_at = time.time(), True, 0.0
                return self._json({"ok": True})
            if path == "/api/events":
                return self._sse(params)
            if path == "/api/sessions":
                return self._json(app.sessions())
            if path == "/api/files":
                return self._json(search_files(app.agent.cwd, params.get("q", "")) if app.cwd_set else [])
            if path == "/api/models":
                spec = app.cfg.resolve(params.get("provider") or app.agent.spec["name"])
                if params.get("base_url"):
                    spec["base_url"] = params["base_url"]
                return self._json(list_models(spec))
            self._deny(404, "Bulunamadı")

        def _sse(self, params: dict) -> None:
            # Akış uzunluğu önceden bilinmediği için Content-Length verilemez. Chunked
            # kodlama yerine (bazı istemcilerde uzun ömürlü akışlarla sorun çıkarabiliyor)
            # HTTP/1.1'in izin verdiği "bağlantı kapanana kadar oku" çerçevelemesini
            # kullanıyoruz: Connection: close ile bu tek yanıtın sonunu bağlantı kapanışı
            # belirler; istemci (EventSource) veriyi geldikçe okur, biz de bağlantıyı açık
            # tutarız.
            last = int(self.headers.get("Last-Event-ID") or params.get("after") or 0)
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self.close_connection = True
            try:
                self.wfile.write(b"retry: 2000\n\n")
                self.wfile.flush()
                while True:
                    with app.cond:
                        pending = [e for e in app.events if e["id"] > last]
                        if not pending:
                            app.cond.wait(timeout=15)
                            pending = [e for e in app.events if e["id"] > last]
                    if not pending:
                        self.wfile.write(b": ka\n\n")
                    for e in pending:
                        self.wfile.write(f"id: {e['id']}\ndata: {json.dumps(e, ensure_ascii=False)}\n\n".encode("utf-8"))
                        last = e["id"]
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                return

        # -- POST ---
        def do_POST(self) -> None:
            if not (self._host_ok() and self._origin_ok() and self._authed()):
                return self._deny()
            n = int(self.headers.get("Content-Length") or 0)
            try:
                body = json.loads(self.rfile.read(n) or b"{}") if n else {}
            except json.JSONDecodeError:
                return self._json({"ok": False, "error": "Geçersiz JSON"}, 400)
            path = self.path.split("?")[0]
            ok, err = True, ""
            if path == "/api/send":
                text = str(body.get("text", "")).strip()
                if not text:
                    ok, err = False, "Boş mesaj."
                elif text.startswith(("/", "!")):
                    fwd = app.command(text)
                    if fwd:
                        ok, err = app.send(fwd)
                else:
                    ok, err = app.send(text)
            elif path == "/api/cancel":
                app.cancel()
            elif path == "/api/permission":
                ok = app.fe.answer(str(body.get("id")), str(body.get("choice")))
            elif path == "/api/cwd":
                ok, err = app.set_cwd(str(body.get("path", "")))
            elif path == "/api/browse":
                p = pick_folder()
                return self._json({"ok": bool(p), "path": p})
            elif path == "/api/connect":
                ok, err = app.connect(body)
            elif path == "/api/mode":
                app.set_mode(str(body.get("mode")))
            elif path == "/api/auto_approve":
                app.agent.auto_approve = bool(body.get("value"))
                app.push_state()
            elif path == "/api/resume":
                ok, err = app.resume(str(body.get("id")))
            elif path == "/api/delete_session":
                ok = app.delete_session(str(body.get("id")))
            elif path == "/api/ui":
                # Apply UI preferences immediately; persistence failures must not
                # terminate the request and appear in the browser as a network error.
                ui = app.cfg.data.setdefault("ui", {})
                if body.get("theme") in ("dark", "light"):
                    ui["theme"] = body["theme"]
                if body.get("size") in ("s", "m", "l"):
                    ui["size"] = body["size"]
                try:
                    app.cfg.save()
                except OSError as exc:
                    app.push_state()
                    return self._json({"ok": False, "error": f"Ayarlar bu oturumda uygulandı ancak kaydedilemedi: {exc}"}, 500)
                app.push_state()
            elif path == "/api/bye":
                app.bye_at = time.time()
            else:
                return self._deny(404, "Bulunamadı")
            self._json({"ok": ok, "error": err})

    return Handler


# --------------------------------------------------------------------------
# Başlatma
# --------------------------------------------------------------------------

def serve(app: App, port: int = 0) -> ThreadingHTTPServer:
    srv = ThreadingHTTPServer(("127.0.0.1", port), make_handler(app))
    srv.daemon_threads = True
    app.server = srv
    app.port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def _watchdog(app: App) -> None:
    while True:
        time.sleep(1.5)
        now = time.time()
        if app.keep_alive:
            continue
        if app.bye_at and now - app.bye_at > 4:
            break
        if app.connected and app.last_ping and now - app.last_ping > 60:
            break
        if not app.connected and now - app.started > 300:
            break
    if app.server:
        app.server.shutdown()
    app.done.set()


def main(argv: list[str] | None = None, pick: bool = False) -> int:
    for stream in ("stdout", "stderr"):  # pythonw'de None olur
        if getattr(sys, stream) is None:
            setattr(sys, stream, open(os.devnull, "w"))
    p = argparse.ArgumentParser(prog="openclient-gui", description="OpenClient masaüstü uygulaması")
    p.add_argument("--cwd", help="başlangıç proje klasörü")
    p.add_argument("--pick", action="store_true", help="başlangıçta klasör seçtir")
    p.add_argument("-p", "--provider")
    p.add_argument("-m", "--model")
    p.add_argument("--base-url")
    p.add_argument("-y", "--yes", action="store_true")
    p.add_argument("--port", type=int, default=0)
    p.add_argument("--no-open", action="store_true", help="pencere açma, yalnızca adresi yazdır")
    p.add_argument("--keep-alive", action="store_true")
    args = p.parse_args(argv)

    cfg = Config()
    spec = cfg.resolve(args.provider, args.model, args.base_url)
    cwd = Path(args.cwd).expanduser().resolve() if args.cwd else (None if (pick or args.pick) else Path.cwd())
    app = App(cfg, spec, cwd, auto_approve=args.yes, keep_alive=args.keep_alive)
    srv = serve(app, args.port)
    url = f"http://127.0.0.1:{app.port}/?t={app.token}"
    if args.no_open:
        print(url, flush=True)
    else:
        open_window(url)
    threading.Thread(target=_watchdog, args=(app,), daemon=True).start()
    try:
        while not app.done.wait(0.5):
            pass
    except KeyboardInterrupt:
        srv.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
