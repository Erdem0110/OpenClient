// OpenClient — arayüz mantığı. Tek dosya, bağımlılıksız (vanilla JS).
// Sunucuyla SSE (/api/events) üzerinden canlı konuşur, komutları POST ile gönderir.
"use strict";

/* ========================================================================
   Yardımcılar
   ======================================================================== */

const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
const el = (tag, cls, html) => { const n = document.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; };
const esc = (s) => String(s ?? "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

function fmtTime(sec) {
  if (sec < 60) return sec.toFixed(1) + "s";
  const m = Math.floor(sec / 60), s = Math.round(sec % 60);
  return `${m}d ${s}s`;
}
function fmtNum(n) { return (n || 0).toLocaleString("tr-TR"); }

async function api(path, body) {
  const opts = body === undefined ? { method: "GET" } : { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) };
  let r;
  try {
    r = await fetch(path, opts);
  } catch {
    toast("Sunucuya ulaşılamıyor.", true);
    throw new Error("network");
  }
  const ct = r.headers.get("content-type") || "";
  const data = ct.includes("json") ? await r.json().catch(() => ({})) : {};
  if (!r.ok && r.status !== 400) {
    toast((data && data.error) || `İstek başarısız (${r.status})`, true);
  } else if (data && data.ok === false && data.error) {
    toast(data.error, true);
  }
  return data;
}

let toastTimer = null;
function toast(msg, isErr) {
  let t = $("#toast");
  if (t) t.remove();
  t = el("div", "toast" + (isErr ? " err" : ""), esc(msg));
  t.id = "toast";
  document.body.appendChild(t);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.remove(), 3600);
}

function raf(fn) {
  let scheduled = false, args = null;
  return (...a) => {
    args = a;
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => { scheduled = false; fn(...args); });
  };
}

/* ========================================================================
   Markdown + kod vurgulama (hafif, bağımlılıksız)
   ======================================================================== */

const MD_LANG_LABEL = { py: "python", js: "javascript", ts: "typescript", sh: "bash", rb: "ruby", yml: "yaml" };

function highlightCode(code) {
  let s = esc(code);
  const KW = /\b(def|class|function|const|let|var|return|if|elif|else|for|while|import|from|as|try|except|finally|with|in|is|not|and|or|async|await|new|this|self|public|private|protected|static|void|int|float|bool|string|True|False|None|true|false|null|nil|undefined|struct|enum|switch|case|break|continue|throw|throws|catch|export|default|interface|type|impl|fn|pub|match|use|mut|package|namespace|extends|implements|yield|lambda|del|global|raise|assert)\b/g;
  const parts = [];
  let i = 0;
  const re = /(#.*|\/\/.*)|("(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'|`(?:[^`\\\n]|\\.)*`)|(\b\d+(?:\.\d+)?\b)/g;
  let m;
  while ((m = re.exec(s))) {
    parts.push(s.slice(i, m.index).replace(KW, '<span class="tk-k">$&</span>').replace(/\b([A-Za-z_]\w*)(?=\()/g, '<span class="tk-f">$1</span>'));
    if (m[1]) parts.push(`<span class="tk-c">${m[1]}</span>`);
    else if (m[2]) parts.push(`<span class="tk-s">${m[2]}</span>`);
    else if (m[3]) parts.push(`<span class="tk-n">${m[3]}</span>`);
    i = re.lastIndex;
  }
  parts.push(s.slice(i).replace(KW, '<span class="tk-k">$&</span>').replace(/\b([A-Za-z_]\w*)(?=\()/g, '<span class="tk-f">$1</span>'));
  return parts.join("");
}

function inlineMd(text) {
  let s = esc(text);
  const codes = [];
  s = s.replace(/`([^`\n]+)`/g, (_, c) => { codes.push(c); return `\u0000${codes.length - 1}\u0000`; });
  s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  s = s.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");
  s = s.replace(/(?<![\w*])\*(?!\s)([^*\n]+?)(?<!\s)\*(?![\w*])/g, "<em>$1</em>");
  s = s.replace(/(?<!\w)_([^_\n]+)_(?!\w)/g, "<em>$1</em>");
  s = s.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${codes[+i]}</code>`);
  return s;
}

function mdRender(src) {
  const lines = String(src || "").replace(/\r\n/g, "\n").split("\n");
  const out = [];
  let inCode = false, codeLang = "", codeBuf = [];
  let para = [];
  let list = null; // {type:'ul'|'ol', items:[]}
  let quote = [];
  let table = null; // {head:[], rows:[]}

  const flushPara = () => { if (para.length) { out.push(`<p>${inlineMd(para.join(" "))}</p>`); para = []; } };
  const flushList = () => { if (list) { out.push(`<${list.type}>${list.items.map((i) => `<li>${inlineMd(i)}</li>`).join("")}</${list.type}>`); list = null; } };
  const flushQuote = () => { if (quote.length) { out.push(`<blockquote>${inlineMd(quote.join(" "))}</blockquote>`); quote = []; } };
  const flushTable = () => {
    if (!table) return;
    const row = (cells, tag) => `<tr>${cells.map((c) => `<${tag}>${inlineMd(c.trim())}</${tag}>`).join("")}</tr>`;
    out.push(`<table><thead>${row(table.head, "th")}</thead><tbody>${table.rows.map((r) => row(r, "td")).join("")}</tbody></table>`);
    table = null;
  };
  const flushAll = () => { flushPara(); flushList(); flushQuote(); flushTable(); };

  const splitCells = (l) => l.trim().replace(/^\||\|$/g, "").split("|");

  for (let idx = 0; idx < lines.length; idx++) {
    const line = lines[idx];
    const t = line.trim();

    if (/^```/.test(t)) {
      if (!inCode) {
        flushAll();
        inCode = true; codeLang = t.slice(3).trim(); codeBuf = [];
      } else {
        inCode = false;
        const lang = codeLang ? (MD_LANG_LABEL[codeLang] || codeLang) : "text";
        out.push(`<div class="code"><div class="code-h"><span>${esc(lang)}</span><button class="cp" type="button" title="Kopyala"><svg class="i"><use href="#i-copy"/></svg><span>Kopyala</span></button></div><pre><code>${highlightCode(codeBuf.join("\n"))}</code></pre></div>`);
      }
      continue;
    }
    if (inCode) { codeBuf.push(line); continue; }

    if (!t) { flushAll(); continue; }

    const h = /^(#{1,6})\s+(.*)$/.exec(t);
    if (h) { flushAll(); out.push(`<h${h[1].length}>${inlineMd(h[2])}</h${h[1].length}>`); continue; }

    if (/^([-*_])\1{2,}\s*$/.test(t)) { flushAll(); out.push("<hr>"); continue; }

    if (t.startsWith(">")) { flushPara(); flushList(); out.push.apply(0, []); quote.push(t.replace(/^>\s?/, "")); continue; }
    if (quote.length) flushQuote();

    if (/^\|.*\|$/.test(t) && lines[idx + 1] && /^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?$/.test(lines[idx + 1].trim())) {
      flushAll();
      table = { head: splitCells(t), rows: [] };
      idx++;
      while (lines[idx + 1] && /^\|.*\|$/.test(lines[idx + 1].trim())) { idx++; table.rows.push(splitCells(lines[idx])); }
      flushTable();
      continue;
    }

    const ol = /^(\s*)(\d+)[.)]\s+(.*)$/.exec(line);
    const ul = /^(\s*)[-*+]\s+(.*)$/.exec(line);
    if (ol || ul) {
      flushPara();
      const type = ol ? "ol" : "ul";
      const text = ol ? ol[3] : ul[2];
      if (!list || list.type !== type) { flushList(); list = { type, items: [] }; }
      list.items.push(text);
      continue;
    }
    flushList();
    para.push(t);
  }
  flushAll();
  return out.join("");
}

/* ========================================================================
   Diff görüntüleme
   ======================================================================== */

function diffHtml(text) {
  const lines = String(text || "").split("\n");
  return lines.map((l) => {
    let cls = "m";
    if (l.startsWith("+++") || l.startsWith("---")) cls = "m";
    else if (l.startsWith("@@")) cls = "h";
    else if (l.startsWith("+")) cls = "a";
    else if (l.startsWith("-")) cls = "d";
    return `<div class="${cls}">${esc(l) || "&nbsp;"}</div>`;
  }).join("");
}
function diffStats(text) {
  let a = 0, d = 0;
  for (const l of String(text || "").split("\n")) {
    if (l.startsWith("+++") || l.startsWith("---")) continue;
    if (l.startsWith("+")) a++; else if (l.startsWith("-")) d++;
  }
  return { a, d };
}

/* ========================================================================
   Araç meta verisi
   ======================================================================== */

const TOOL_META = {
  read: { icon: "i-file", kind: "k-read", label: "Read" },
  write: { icon: "i-pencil", kind: "k-write", label: "Write" },
  edit: { icon: "i-pencil", kind: "k-write", label: "Edit" },
  bash: { icon: "i-term", kind: "k-bash", label: "Bash" },
  glob: { icon: "i-search", kind: "k-read", label: "Glob" },
  grep: { icon: "i-search", kind: "k-read", label: "Grep" },
  ls: { icon: "i-folder", kind: "k-read", label: "Ls" },
  webfetch: { icon: "i-globe", kind: "k-web", label: "Webfetch" },
};
function toolMeta(name) { return TOOL_META[name] || { icon: "i-bolt", kind: "", label: name }; }

/* ========================================================================
   Uygulama durumu
   ======================================================================== */

const state = {
  cwd: null, folder: null, branch: null, provider: null, model: null, mode: "build",
  autoApprove: false, busy: false, session: null, providers: [], recent: [], ui: {},
};
const thread = $("#thread"), scroller = $("#scroller");
let curTurn = null, curThink = null, curSay = null, curSayRaw = "", curTool = null, curToolHasBody = false;
const permMap = new Map();
let stickToBottom = true;
let sessionsCache = [];

/* ---- kaydırma ---- */
scroller.addEventListener("scroll", () => {
  stickToBottom = scroller.scrollTop + scroller.clientHeight > scroller.scrollHeight - 80;
  $("#toBottom").classList.toggle("hidden", stickToBottom);
});
function scrollDown(force) {
  if (force || stickToBottom) requestAnimationFrame(() => { scroller.scrollTop = scroller.scrollHeight; });
}
$("#toBottom").addEventListener("click", () => { stickToBottom = true; scrollDown(true); });

/* ---- rail / turn yönetimi ---- */
function ensureTurn() {
  if (curTurn) return curTurn;
  clearWelcome();
  const t = el("div", "turn");
  const rail = el("div", "rail empty");
  t.appendChild(rail);
  thread.appendChild(t);
  curTurn = { el: t, rail };
  return curTurn;
}
function addItem(cls) {
  const t = ensureTurn();
  t.rail.classList.remove("empty");
  const it = el("div", "item " + cls);
  t.rail.appendChild(it);
  scrollDown();
  return it;
}
function newUserTurn(text) {
  clearWelcome();
  finalizeOpenItems();
  const t = el("div", "turn");
  const bubble = el("div", "user");
  if (text.startsWith("/") || text.startsWith("!")) {
    const sp = text.indexOf(" ");
    const head = sp === -1 ? text : text.slice(0, sp);
    const rest = sp === -1 ? "" : text.slice(sp);
    bubble.innerHTML = `<span class="cmd">${esc(head)}</span>${esc(rest)}`;
  } else {
    bubble.textContent = text;
  }
  t.appendChild(bubble);
  const rail = el("div", "rail empty");
  t.appendChild(rail);
  thread.appendChild(t);
  curTurn = { el: t, rail };
  scrollDown(true);
}
function finalizeOpenItems() {
  if (curSay) { curSay.classList.remove("live"); }
  curThink = null; curSay = null; curSayRaw = ""; curTool = null; curToolHasBody = false;
}

/* ---- karşılama ekranı ---- */
function clearWelcome() { const w = $(".hero", thread) || $(".welcome", thread); if (w) w.remove(); }

function renderWelcome() {
  thread.innerHTML = "";
  curTurn = null;
  if (!state.cwd) {
    const h = el("div", "hero");
    h.innerHTML = `
      <div class="logo"><i>▌</i> <b style="color:var(--text)">open</b><span style="color:var(--dim)">client</span></div>
      <h1>Bir proje klasörü seç</h1>
      <p>OpenClient, seçtiğin klasörde dosya okur, düzenler ve komut çalıştırır. Önce üzerinde çalışacağımız klasörü belirle.</p>
      <div class="pick">
        <input class="field" id="heroPath" placeholder="Klasör yolu yapıştır (ör. C:\\Users\\sen\\proje)" autocomplete="off" spellcheck="false">
        <button class="btn" id="heroBrowse"><svg class="i"><use href="#i-folder"/></svg>Gözat</button>
        <button class="btn primary" id="heroOpen">Aç</button>
      </div>
      <div class="recent" id="heroRecent"></div>`;
    thread.appendChild(h);
    renderRecent($("#heroRecent"), state.recent);
    $("#heroBrowse").addEventListener("click", browseFolder);
    $("#heroOpen").addEventListener("click", () => openPath($("#heroPath").value));
    $("#heroPath").addEventListener("keydown", (e) => { if (e.key === "Enter") openPath(e.target.value); });
  } else {
    const ideas = [
      ["Bu projeyi tanıt", "dosyaları incele, yapıyı ve amacı özetle"],
      ["Testleri çalıştır", "başarısız olanları bul ve düzelt"],
      ["TODO'ları listele", "kod tabanındaki yarım işleri bul"],
      ["AGENTS.md yaz", "/init komutuyla proje kurallarını çıkar"],
    ];
    const h = el("div", "hero welcome");
    h.innerHTML = `
      <div class="logo"><i>▌</i> <b style="color:var(--text)">open</b><span style="color:var(--dim)">client</span></div>
      <h1>${esc(state.folder || "Proje")}</h1>
      <p>Ne üzerinde çalışalım? Bir görev yaz ya da aşağıdan başla.</p>
      <div class="ideas" id="ideaList"></div>`;
    thread.appendChild(h);
    const list = $("#ideaList", h);
    ideas.forEach(([title, desc]) => {
      const b = el("button", "idea");
      b.innerHTML = `<span><b>${esc(title)}</b><span class="d">${esc(desc)}</span></span><svg class="i"><use href="#i-chev"/></svg>`;
      b.addEventListener("click", () => { input.value = title; autoSize(); input.focus(); });
      list.appendChild(b);
    });
  }
}

function renderRecent(container, dirs) {
  if (!container) return;
  if (!dirs || !dirs.length) { container.innerHTML = ""; return; }
  container.innerHTML = `<h6>Son klasörler</h6>`;
  dirs.forEach((d) => {
    const parts = d.replace(/\\/g, "/").split("/").filter(Boolean);
    const name = parts[parts.length - 1] || d;
    const b = el("button", "r-item");
    b.innerHTML = `<svg class="i"><use href="#i-folder"/></svg><span style="min-width:0"><span class="n">${esc(name)}</span><span class="p">${esc(d)}</span></span>`;
    b.addEventListener("click", () => openPath(d));
    container.appendChild(b);
  });
}

async function browseFolder() {
  // /api/browse sunucuda POST olarak tanımlı; GET isteği 404 döndürür.
  const r = await api("/api/browse", {});
  if (r.ok && r.path) openPath(r.path);
}
async function openPath(path) {
  if (!path || !path.trim()) return;
  const r = await api("/api/cwd", { path: path.trim() });
  if (r.ok) { closeDialogs(); }
}

/* ========================================================================
   Model/araç olaylarının render edilmesi
   ======================================================================== */

function setThinking(on, label) {
  if (on) {
    finalizeSayIfNeeded(false);
    curThink = addItem("think wait");
    curThink.classList.remove("wait");
    curThink.innerHTML = `<div class="think"><div class="dots"><i></i><i></i><i></i></div><span>${esc(label || "Düşünüyor")}…</span></div>`;
  }
}
function finalizeSayIfNeeded(final) {
  if (curSay) {
    if (final) curSay.classList.remove("live");
  } else if (curThink) {
    curThink.remove();
  }
  if (final) { curThink = null; curSay = null; curSayRaw = ""; }
}
const renderSay = raf(() => { if (curSay) { $(".say-body", curSay).innerHTML = mdRender(curSayRaw); scrollDown(); } });

function onText(delta) {
  assistantSpeechBuffer += String(delta || "");
  if (curThink) { curThink.remove(); curThink = null; }
  if (!curSay) {
    curSay = addItem("say");
    curSay.innerHTML = `<div class="say-body live"></div>`;
  }
  curSayRaw += delta;
  renderSay();
}
function onTextEnd() {
  finalizeSayIfNeeded(true);
  if (assistantSpeechBuffer.trim()) speakText(assistantSpeechBuffer);
  assistantSpeechBuffer = "";
}

function toolStatus(card, status) {
  const meta = card._meta;
  card.classList.remove("run", "wait", "err");
  if (status === "run") card.classList.add("run");
  else if (status === "wait") card.classList.add("wait");
  else if (status === "bad") card.classList.add("err");
  const st = $(".st", card);
  st.textContent = status === "bad" ? "hata" : "";
  st.className = "st" + (status === "ok" ? " ok" : status === "bad" ? " bad" : status === "wait" ? " wt" : "");
}

function onToolStart(name, summary, status) {
  finalizeSayIfNeeded(true);
  const meta = toolMeta(name);
  const it = addItem(`item ${meta.kind} run`);
  it._meta = meta;
  const wrap = el("div", "tool");
  wrap.innerHTML = `
    <button class="tool-h" type="button">
      <svg class="i ic"><use href="#${meta.icon}"/></svg>
      <span class="nm">${esc(meta.label)}</span>
      <span class="sm">${esc(summary || "")}</span>
      <span class="st"></span>
      <svg class="i chev"><use href="#i-chev"/></svg>
    </button>
    <div class="tool-b"></div>`;
  it.appendChild(wrap);
  $(".tool-h", wrap).addEventListener("click", () => wrap.classList.toggle("open"));
  curTool = wrap;
  curToolHasBody = false;
  toolStatus(it, status === "error" ? "bad" : "run");
  if (status === "error") curTool = null; // gövde gelmeyecek
  scrollDown();
}
function toolItemEl() { return curTool ? curTool.closest(".item") : null; }

function onToolOut(text, isError) {
  if (!curTool) return;
  const body = $(".tool-b", curTool);
  body.appendChild(el("pre", "out" + (isError ? " bad" : ""), esc(text)));
  if (!curToolHasBody) { curToolHasBody = true; if (text.split("\n").length < 6 && !isError) curTool.classList.add("open"); }
  toolStatus(toolItemEl(), isError ? "bad" : "ok");
  curTool = null;
  scrollDown();
}
function onToolDiff(text) {
  if (!curTool) return;
  const body = $(".tool-b", curTool);
  body.appendChild(el("div", "diff", diffHtml(text)));
  const { a, d } = diffStats(text);
  const sm = $(".sm", curTool);
  if (sm) sm.insertAdjacentHTML("afterend", `<span class="st ok" style="font-family:var(--mono)">${a ? "+" + a : ""}${d ? " -" + d : ""}</span>`);
  toolStatus(toolItemEl(), "ok");
  curTool = null;
  scrollDown();
}
function onToolNote(text, level) {
  if (!curTool) return;
  const body = $(".tool-b", curTool);
  body.appendChild(el("div", "note" + (level === "success" ? " success" : level === "error" ? " error" : ""), esc(text)));
  toolStatus(toolItemEl(), level === "error" ? "bad" : "ok");
  curTool = null;
  scrollDown();
}

function onPermission(id, tool, summary, preview) {
  if (!curTool) return;
  const item = toolItemEl();
  toolStatus(item, "wait");
  const meta = toolMeta(tool);
  const card = el("div", "perm");
  let pv = "";
  if (preview) pv = preview.kind === "diff" ? `<div class="pv diff">${diffHtml(preview.text)}</div>` : `<div class="pv"><pre class="out" style="border:0">${esc(preview.text)}</pre></div>`;
  card.innerHTML = `
    <div class="q"><svg class="i"><use href="#i-shield"/></svg><span>İzin gerekli — ${esc(meta.label)}</span></div>
    <div style="color:var(--dim);font:400 12.5px var(--mono)">${esc(summary || "")}</div>
    ${pv}
    <div class="acts">
      <button class="btn" data-c="deny">Reddet</button>
      <button class="btn" data-c="always">Oturum boyunca izin ver</button>
      <button class="btn primary" data-c="once">İzin ver</button>
    </div>`;
  curTool.insertBefore(card, $(".tool-b", curTool));
  $$("[data-c]", card).forEach((b) => b.addEventListener("click", () => {
    api("/api/permission", { id, choice: b.dataset.c });
  }));
  permMap.set(id, card);
  curTool.classList.add("open");
  scrollDown(true);
}
function onPermissionDone(id, choice) {
  const card = permMap.get(id);
  if (!card) return;
  const label = { once: "İzin verildi", always: "Oturum boyunca izin verildi", deny: "Reddedildi" }[choice] || choice;
  card.className = "perm done";
  card.innerHTML = `<span style="color:${choice === "deny" ? "var(--red)" : "var(--green)"}">${esc(label)}</span>`;
  permMap.delete(id);
}

function onNotice(level, text) {
  finalizeSayIfNeeded(true);
  const cls = level === "error" ? "err" : level === "warn" ? "warn" : "info";
  const it = addItem(`item ${cls}`);
  const icon = level === "error" ? "i-alert" : level === "warn" ? "i-alert" : "i-info";
  it.innerHTML = `<div class="msg ${cls}"><svg class="i"><use href="#${icon}"/></svg><span>${esc(text)}</span></div>`;
  scrollDown();
}

function onFooter(agent, model, seconds, tin, tout) {
  finalizeSayIfNeeded(true);
  const it = addItem("item meta");
  const parts = [agent === "plan" ? "Plan" : "Build", model, fmtTime(seconds)];
  if (tin || tout) parts.push(`${fmtNum(tin)}↑ ${fmtNum(tout)}↓`);
  it.textContent = parts.join(" · ");
  scrollDown();
  refreshSessions();
}

/* ========================================================================
   Geçmişten yeniden kurma (oturum devam ettirme)
   ======================================================================== */

function applyEvent(ev) {
  switch (ev.type) {
    case "reset": thread.innerHTML = ""; curTurn = null; finalizeOpenItems(); permMap.clear(); break;
    case "state": applyState(ev.state); break;
    case "status": state.busy = ev.busy; applyBusy(); break;
    case "user": newUserTurn(ev.text); break;
    case "thinking": setThinking(ev.on, ev.label); break;
    case "text": onText(ev.delta); break;
    case "assistant": onText(ev.text); onTextEnd(); break; // geçmiş yeniden kurulurken
    case "text_end": onTextEnd(); break;
    case "tool": onToolStart(ev.name, ev.summary, ev.status); break;
    case "tool_out": onToolOut(ev.text, ev.error); break;
    case "tool_diff": onToolDiff(ev.text); break;
    case "tool_note": onToolNote(ev.text, ev.level); break;
    case "preview": break;
    case "permission": onPermission(ev.pid, ev.tool, ev.summary, ev.preview); break;
    case "permission_done": onPermissionDone(ev.pid, ev.choice); break;
    case "notice": onNotice(ev.level, ev.text); break;
    case "footer": onFooter(ev.agent, ev.model, ev.seconds, ev.tin, ev.tout); break;
  }
}

/* ========================================================================
   Genel durum (state) uygulanması: topbar, sidebar, composer
   ======================================================================== */

function applyState(s) {
  Object.assign(state, {
    cwd: s.cwd, folder: s.folder, branch: s.branch, provider: s.provider, model: s.model, mode: s.mode,
    autoApprove: s.auto_approve, busy: s.busy, session: s.session, providers: s.providers, recent: s.recent || [],
    ui: s.ui || {},
  });
  $("#ver").textContent = "v" + s.version;
  $("#folderName").textContent = state.folder || "Klasör seç";
  $("#branch").classList.toggle("hidden", !state.branch);
  $("#branchName").textContent = state.branch || "";
  $("#modelChip #modelTxt").textContent = state.model || "model";
  $("#modelTxt").textContent = state.model || "model";
  $$("#seg button").forEach((b) => b.classList.toggle("on", b.dataset.v === state.mode));
  $("#modeChip .dot").style.background = state.mode === "plan" ? "var(--violet)" : "var(--accent)";
  $("#modeTxt").textContent = state.mode === "plan" ? "Plan" : "Build";
  $("#composer").classList.toggle("plan", state.mode === "plan");
  const prov = state.providers.find((p) => p.name === state.provider);
  $("#provModel").textContent = state.model || "—";
  $("#provName").textContent = prov ? prov.label : state.provider || "";
  const dot = $("#provDot");
  dot.className = "dot " + (prov ? (prov.ready ? "ok" : "no") : "");
  if (s.ui) applyUi(s.ui);
  applyBusy();
  if (!thread.children.length || (thread.children.length === 1 && $(".hero", thread))) renderWelcome();
  renderSettingsIfOpen();
  renderInspectorSession();
}

function applyUi(ui) {
  if (ui.theme) document.documentElement.setAttribute("data-theme", ui.theme);
  if (ui.size) document.documentElement.setAttribute("data-size", ui.size);
  $("#themeBtn use").setAttribute("href", (ui.theme === "light") ? "#i-moon" : "#i-sun");
}

function applyBusy() {
  input.disabled = false;
  $("#send").classList.toggle("stop", state.busy);
  $("#send use").setAttribute("href", state.busy ? "#i-stop" : "#i-send");
  $("#send").disabled = !state.busy && !input.value.trim();
  $("#newBtn").disabled = state.busy;
  $("#folderBtn").disabled = state.busy;
}

/* ========================================================================
   SSE bağlantısı
   ======================================================================== */

let es = null;
function connectSSE() {
  es = new EventSource("/api/events");
  es.onmessage = (e) => { try { applyEvent(JSON.parse(e.data)); } catch (err) { console.error("event hatası:", err, e.data); } };
  es.onerror = () => { /* tarayıcı otomatik yeniden bağlanır */ };
}
async function boot() {
  const s = await api("/api/state");
  applyState(s);
  connectSSE();
  refreshSessions();
  setInterval(() => api("/api/ping"), 20000);
  window.addEventListener("beforeunload", () => { navigator.sendBeacon && navigator.sendBeacon("/api/bye", "{}"); });
}

/* ========================================================================
   Yazı alanı (composer)
   ======================================================================== */

const input = $("#input");

// Sesli konuşma: tarayıcının Web Speech API'si kullanılır; destek yoksa açıklayıcı mesaj gösterilir.
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let voiceOutputEnabled = false;
let assistantSpeechBuffer = "";
let assistantSpeechUtterance = null;

function speakText(text) {
  if (!voiceOutputEnabled || !("speechSynthesis" in window) || !text.trim()) return;
  window.speechSynthesis.cancel();
  assistantSpeechUtterance = new SpeechSynthesisUtterance(text.trim());
  assistantSpeechUtterance.lang = "tr-TR";
  window.speechSynthesis.speak(assistantSpeechUtterance);
}
const voiceInputBtn = $("#voiceInput");
const voiceOutputBtn = $("#voiceOutput");
if (voiceInputBtn) {
  voiceInputBtn.addEventListener("click", () => {
    if (!SpeechRecognition) {
      toast("Bu tarayıcı ses tanımayı desteklemiyor. Edge veya Chrome deneyebilirsin.", true);
      return;
    }
    if (recognition) { recognition.stop(); return; }
    recognition = new SpeechRecognition();
    recognition.lang = "tr-TR";
    recognition.continuous = false;
    recognition.interimResults = true;
    let finalText = "";
    recognition.onresult = (event) => {
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const part = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += part;
        else interim += part;
      }
      input.value = [finalText, interim].filter(Boolean).join(" ").trim();
      autoSize();
    };
    recognition.onerror = (event) => toast("Ses tanıma hatası: " + (event.error || "bilinmiyor"), true);
    recognition.onend = () => {
      recognition = null;
      voiceInputBtn.classList.remove("active");
      if (finalText.trim()) { input.value = finalText.trim(); autoSize(); }
    };
    voiceInputBtn.classList.add("active");
    try { recognition.start(); } catch (err) { recognition = null; voiceInputBtn.classList.remove("active"); toast("Mikrofon başlatılamadı. Tarayıcı mikrofon iznini kontrol et.", true); }
  });
}
if (voiceOutputBtn) {
  voiceOutputBtn.addEventListener("click", () => {
    voiceOutputEnabled = !voiceOutputEnabled;
    voiceOutputBtn.classList.toggle("active", voiceOutputEnabled);
    if (!voiceOutputEnabled && "speechSynthesis" in window) window.speechSynthesis.cancel();
    toast(voiceOutputEnabled ? "Sesli yanıt açıldı." : "Sesli yanıt kapatıldı.");
  });
}

function autoSize() {
  input.style.height = "auto";
  input.style.height = clamp(input.scrollHeight, 40, 240) + "px";
  $("#send").disabled = !state.busy && !input.value.trim();
}
input.addEventListener("input", () => { autoSize(); updateMenu(); });
autoSize();

function sendCurrent() {
  const text = input.value;
  if (!text.trim() || state.busy) return;
  api("/api/send", { text: text.trim() });
  input.value = "";
  autoSize();
  closeMenu();
}
$("#send").addEventListener("click", () => { if (state.busy) api("/api/cancel"); else sendCurrent(); });
input.addEventListener("keydown", (e) => {
  if (menuOpen()) {
    if (e.key === "ArrowDown") { e.preventDefault(); menuMove(1); return; }
    if (e.key === "ArrowUp") { e.preventDefault(); menuMove(-1); return; }
    if ((e.key === "Enter" || e.key === "Tab") && !e.shiftKey) { e.preventDefault(); menuSelect(); return; }
    if (e.key === "Escape") { closeMenu(); return; }
  }
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendCurrent(); return; }
  if (e.key === "Tab") { e.preventDefault(); toggleMode(); return; }
  if (e.key === "Escape") { input.blur(); }
});

/* ---- / ve @ menüleri ---- */
const SLASH_CMDS = [
  ["/plan", "salt-okunur plan moduna geç"], ["/build", "düzenleme moduna geç"],
  ["/new", "yeni sohbet başlat"], ["/compact", "bağlamı özetleyip küçült"],
  ["/yolo", "tüm izinleri otomatik onayla"], ["/model", "model değiştir: /model <ad>"],
  ["/init", "projeyi inceleyip AGENTS.md yaz"], ["/resume", "oturumu sürdür: /resume <id>"],
];
const menu = $("#menu");
let menuItems = [], menuIdx = -1, menuKind = null, menuStart = 0;

function menuOpen() { return !menu.classList.contains("hidden"); }
function closeMenu() { menu.classList.add("hidden"); menuKind = null; }
function renderMenu() {
  if (!menuItems.length) return closeMenu();
  menu.innerHTML = menuItems.map((it, i) => `<button class="mi${i === menuIdx ? " on" : ""}" data-i="${i}">${it.html}</button>`).join("");
  menu.classList.remove("hidden");
  $$(".mi", menu).forEach((b) => b.addEventListener("click", () => { menuIdx = +b.dataset.i; menuSelect(); }));
}
function menuMove(d) { if (!menuItems.length) return; menuIdx = (menuIdx + d + menuItems.length) % menuItems.length; renderMenu(); }
function menuSelect() {
  const it = menuItems[menuIdx];
  if (!it) return closeMenu();
  const before = input.value.slice(0, menuStart);
  const after = input.value.slice(input.selectionStart);
  input.value = before + it.insert + " " + after;
  closeMenu();
  input.focus();
  const pos = (before + it.insert + " ").length;
  input.setSelectionRange(pos, pos);
  autoSize();
}
let fileSearchToken = 0;
async function updateMenu() {
  const v = input.value, pos = input.selectionStart;
  const upto = v.slice(0, pos);
  const slash = /(^|\s)\/(\w*)$/.exec(upto);
  const at = /(^|\s)@(\S*)$/.exec(upto);
  if (slash && upto.trim() === "/" + slash[2]) {
    menuKind = "slash"; menuStart = upto.length - slash[2].length - 1;
    const q = slash[2].toLowerCase();
    menuItems = SLASH_CMDS.filter((c) => c[0].slice(1).startsWith(q)).map((c) => ({ insert: c[0], html: `<span class="c">${c[0]}</span><span class="t">${esc(c[1])}</span>` }));
    menuIdx = menuItems.length ? 0 : -1;
    renderMenu();
  } else if (at) {
    menuKind = "file"; menuStart = upto.length - at[2].length - 1;
    const token = ++fileSearchToken;
    if (!state.cwd) return closeMenu();
    const r = await api(`/api/files?q=${encodeURIComponent(at[2])}`);
    if (token !== fileSearchToken) return;
    const files = Array.isArray(r) ? r : [];
    menuItems = files.map((f) => ({ insert: "@" + f, html: `<svg class="i"><use href="#i-file"/></svg><span class="f">${esc(f)}</span>` }));
    menuIdx = menuItems.length ? 0 : -1;
    renderMenu();
  } else {
    closeMenu();
  }
}

/* ---- kod kopyalama (olay devretme) ---- */
thread.addEventListener("click", (e) => {
  const cp = e.target.closest(".cp");
  if (!cp) return;
  const code = cp.closest(".code").querySelector("code").textContent;
  navigator.clipboard?.writeText(code).then(() => {
    const span = cp.querySelector("span");
    const old = span.textContent; span.textContent = "Kopyalandı";
    setTimeout(() => { span.textContent = old; }, 1400);
  });
});

/* ========================================================================
   Mod / tema / yan panel
   ======================================================================== */

function toggleMode() { api("/api/mode", { mode: state.mode === "plan" ? "build" : "plan" }); }
$$("#seg button").forEach((b) => b.addEventListener("click", () => api("/api/mode", { mode: b.dataset.v })));
$("#modeChip").addEventListener("click", toggleMode);
$("#modelChip").addEventListener("click", () => openSettings("provider"));
$("#provBtn").addEventListener("click", () => openSettings("provider"));
$("#setBtn").addEventListener("click", () => openSettings("provider"));

$("#themeBtn").addEventListener("click", () => {
  const next = (state.ui.theme === "light") ? "dark" : "light";
  applyUi({ theme: next });
  api("/api/ui", { theme: next });
});

$("#sideBtn").addEventListener("click", () => $("#app").classList.toggle("no-side"));
$("#inspBtn").addEventListener("click", () => {
  const app = $("#app");
  app.classList.toggle("has-insp");
  app.style.setProperty("--inspector", app.classList.contains("has-insp") ? "320px" : "0px");
});

$("#newBtn").addEventListener("click", () => { if (!state.busy) api("/api/send", { text: "/new" }); });
$("#folderBtn").addEventListener("click", openFolderDialog);

/* ========================================================================
   Pencereler (dialog): klasör / ayarlar / komut paleti
   ======================================================================== */

function openDialog(title, bodyHtml, cls) {
  closeDialogs();
  const scrim = el("div", "scrim");
  scrim.id = "scrim";
  const dlg = el("div", "dialog" + (cls ? " " + cls : ""));
  dlg.innerHTML = `<div class="d-head"><span>${esc(title)}</span><button class="icon-btn" id="dlgX"><svg class="i"><use href="#i-x"/></svg></button></div>${bodyHtml}`;
  scrim.appendChild(dlg);
  document.body.appendChild(scrim);
  scrim.addEventListener("mousedown", (e) => { if (e.target === scrim) closeDialogs(); });
  $("#dlgX", dlg).addEventListener("click", closeDialogs);
  return dlg;
}
function closeDialogs() { const s = $("#scrim"); if (s) s.remove(); }
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeDialogs(); });

function openFolderDialog() {
  const dlg = openDialog("Proje klasörü", `
    <div style="padding:16px">
      <div class="pick">
        <input class="field" id="fdPath" placeholder="Klasör yolu" autocomplete="off" spellcheck="false" value="${esc(state.cwd || "")}">
        <button class="btn" id="fdBrowse"><svg class="i"><use href="#i-folder"/></svg>Gözat</button>
        <button class="btn primary" id="fdOpen">Aç</button>
      </div>
      <div class="recent" id="fdRecent"></div>
    </div>`);
  renderRecent($("#fdRecent", dlg), state.recent);
  $("#fdBrowse", dlg).addEventListener("click", browseFolder);
  $("#fdOpen", dlg).addEventListener("click", () => openPath($("#fdPath", dlg).value));
  $("#fdPath", dlg).addEventListener("keydown", (e) => { if (e.key === "Enter") openPath(e.target.value); });
  $("#fdPath", dlg).focus();
}

/* ---- Ayarlar ---- */
let settingsTab = "provider", settingsProvider = null;
function openSettings(tab) {
  settingsTab = tab || "provider";
  settingsProvider = settingsProvider || state.provider;
  const dlg = openDialog("Ayarlar", `<div class="set">
      <nav id="setNav"></nav>
      <div class="pane" id="setPane"></div>
    </div>`, "");
  renderSettingsNav(dlg);
  renderSettingsPane(dlg);
}
function renderSettingsIfOpen() {
  const dlg = $(".dialog .set");
  if (dlg) { renderSettingsNav(dlg.closest(".dialog")); renderSettingsPane(dlg.closest(".dialog")); }
}
function renderSettingsNav(dlg) {
  const nav = $("#setNav", dlg);
  const provRows = state.providers.map((p) => `<button data-p="${p.name}" class="${settingsTab === "provider" && settingsProvider === p.name ? "on" : ""}"><svg class="i"><use href="#i-key"/></svg><span>${esc(p.label)}</span><span class="dot ${p.ready ? "ok" : ""}"></span></button>`).join("");
  nav.innerHTML = `<h6 style="padding:4px 10px;color:var(--faint);font-size:11.5px;font-weight:600">SAĞLAYICI</h6>${provRows}
    <hr>
    <button data-g="general" class="${settingsTab === "general" ? "on" : ""}"><svg class="i"><use href="#i-sliders"/></svg><span>Görünüm</span></button>`;
  $$("[data-p]", nav).forEach((b) => b.addEventListener("click", () => { settingsTab = "provider"; settingsProvider = b.dataset.p; renderSettingsNav(dlg); renderSettingsPane(dlg); }));
  $$("[data-g]", nav).forEach((b) => b.addEventListener("click", () => { settingsTab = b.dataset.g; renderSettingsNav(dlg); renderSettingsPane(dlg); }));
}
async function renderSettingsPane(dlg) {
  const pane = $("#setPane", dlg);
  if (settingsTab === "general") {
    pane.innerHTML = `
      <span class="lbl">Tema</span>
      <div class="seg" style="width:fit-content">
        <button data-th="dark" class="${(state.ui.theme || "dark") !== "light" ? "on" : ""}">Koyu</button>
        <button data-th="light" class="${state.ui.theme === "light" ? "on" : ""}">Açık</button>
      </div>
      <span class="lbl">Yazı boyutu</span>
      <div class="seg" style="width:fit-content">
        <button data-sz="s" class="${state.ui.size === "s" ? "on" : ""}">Küçük</button>
        <button data-sz="m" class="${!state.ui.size || state.ui.size === "m" ? "on" : ""}">Orta</button>
        <button data-sz="l" class="${state.ui.size === "l" ? "on" : ""}">Büyük</button>
      </div>
      <div class="tgl" style="margin-top:18px">
        <div class="tx"><b>Tüm izinleri otomatik onayla</b><span>Dosya yazma, düzenleme ve komutlar için sormadan devam eder. Dikkatli kullan.</span></div>
        <button class="sw ${state.autoApprove ? "on" : ""}" id="yoloSw"></button>
      </div>`;
    $$("[data-th]", pane).forEach((b) => b.addEventListener("click", () => api("/api/ui", { theme: b.dataset.th })));
    $$("[data-sz]", pane).forEach((b) => b.addEventListener("click", () => api("/api/ui", { size: b.dataset.sz })));
    $("#yoloSw", pane).addEventListener("click", () => api("/api/auto_approve", { value: !state.autoApprove }));
    return;
  }
  const p = state.providers.find((x) => x.name === settingsProvider) || state.providers[0];
  if (!p) { pane.innerHTML = `<div class="empty-i">Sağlayıcı yok.</div>`; return; }
  pane.innerHTML = `
    <span class="lbl">Taban adres</span>
    <input class="field" id="spUrl" value="${esc(p.base_url)}">
    ${p.env ? `
    <span class="lbl">API anahtarı ${p.has_key ? '<span style="color:var(--green)">· kayıtlı</span>' : ""}</span>
    <input class="field" id="spKey" type="password" placeholder="${p.has_key ? "değiştirmek için yeni anahtar gir" : esc(p.env) + " ortam değişkeninden de okunur"}" autocomplete="off">` : ""}
    <span class="lbl">Model</span>
    <input class="field" id="spModel" value="${esc(p.model)}">
    <div class="models" id="spModels"></div>
    <div class="row-r">
      ${p.has_key ? '<button class="btn danger" id="spClear">Anahtarı sil</button>' : ""}
      <button class="btn primary" id="spSave">Kaydet ve kullan</button>
    </div>`;
  $("#spSave", pane).addEventListener("click", async () => {
    const body = { provider: p.name, base_url: $("#spUrl", pane).value, model: $("#spModel", pane).value };
    const key = $("#spKey", pane);
    if (key && key.value.trim()) body.api_key = key.value.trim();
    const r = await api("/api/connect", body);
    if (r.ok) toast(`${p.label} etkinleştirildi.`);
  });
  if ($("#spClear", pane)) $("#spClear", pane).addEventListener("click", async () => {
    await api("/api/connect", { provider: p.name, clear_key: true, activate: false });
  });
  api(`/api/models?provider=${p.name}&base_url=${encodeURIComponent($("#spUrl", pane).value)}`).then((models) => {
    if (!Array.isArray(models) || !models.length) return;
    const box = $("#spModels", pane);
    if (!box) return;
    box.innerHTML = models.slice(0, 40).map((m) => `<button data-m="${esc(m)}">${esc(m)}</button>`).join("");
    $$("[data-m]", box).forEach((b) => b.addEventListener("click", () => { $("#spModel", pane).value = b.dataset.m; }));
  });
}

/* ---- Komut paleti ---- */
function openPalette() {
  const dlg = openDialog("", `
    <input class="pal-in" id="palIn" placeholder="Komut ara…" autocomplete="off">
    <div class="pal-list" id="palList"></div>`, "pal");
  dlg.querySelector(".d-head").remove();
  const actions = [
    { t: "Yeni sohbet", k: "Ctrl N", run: () => api("/api/send", { text: "/new" }) },
    { t: "Proje klasörü seç", k: "", run: openFolderDialog },
    { t: "Plan moduna geç", k: "", run: () => api("/api/mode", { mode: "plan" }) },
    { t: "Build moduna geç", k: "", run: () => api("/api/mode", { mode: "build" }) },
    { t: "Bağlamı özetle (/compact)", k: "", run: () => api("/api/send", { text: "/compact" }) },
    { t: "AGENTS.md oluştur (/init)", k: "", run: () => api("/api/send", { text: "/init" }) },
    { t: "Ayarları aç", k: "Ctrl ,", run: () => openSettings("provider") },
    { t: "Temayı değiştir", k: "", run: () => $("#themeBtn").click() },
    { t: "Yan paneli aç/kapat", k: "Ctrl B", run: () => $("#sideBtn").click() },
    { t: "Denetçi panelini aç/kapat", k: "Ctrl J", run: () => $("#inspBtn").click() },
  ];
  const render = (q) => {
    const list = $("#palList", dlg);
    const ql = q.trim().toLowerCase();
    const items = actions.filter((a) => a.t.toLowerCase().includes(ql));
    list.innerHTML = `<h6>Komutlar</h6>` + items.map((a, i) => `<button class="mi" data-i="${i}"><span class="t">${esc(a.t)}</span>${a.k ? `<kbd style="margin-left:auto">${esc(a.k)}</kbd>` : ""}</button>`).join("") || `<div class="empty-i">Sonuç yok</div>`;
    $$("[data-i]", list).forEach((b) => b.addEventListener("click", () => { items[+b.dataset.i].run(); closeDialogs(); }));
  };
  render("");
  const inp = $("#palIn", dlg);
  inp.addEventListener("input", () => render(inp.value));
  inp.focus();
}

/* ========================================================================
   Yan panel: oturumlar
   ======================================================================== */

async function refreshSessions() {
  const list = await api("/api/sessions");
  sessionsCache = Array.isArray(list) ? list : [];
  renderSessions();
}
function renderSessions() {
  const box = $("#sessions");
  if (!sessionsCache.length) { box.innerHTML = `<div class="s-empty">Henüz oturum yok.</div>`; return; }
  box.innerHTML = `<h6>Son oturumlar</h6>` + sessionsCache.map((s) => `
    <button class="s-item${s.id === state.session ? " on" : ""}" data-id="${esc(s.id)}">
      <span class="t">${esc(s.title || "(başlıksız)")}</span>
      <span class="d">${esc(s.model || "")}</span>
      <span class="del" data-del="${esc(s.id)}" title="Sil"><svg class="i"><use href="#i-trash"/></svg></span>
    </button>`).join("");
  $$(".s-item", box).forEach((b) => b.addEventListener("click", (e) => { if (e.target.closest("[data-del]")) return; api("/api/resume", { id: b.dataset.id }); }));
  $$("[data-del]", box).forEach((b) => b.addEventListener("click", async (e) => {
    e.stopPropagation();
    await api("/api/delete_session", { id: b.dataset.del });
    refreshSessions();
  }));
}

/* ========================================================================
   Denetçi paneli: değişiklikler + oturum bilgisi
   ======================================================================== */

const fileChanges = new Map(); // yol -> {addHtml, a, d}
const inspTabs = $("#inspTabs");
let inspTab = "chg";
inspTabs.addEventListener("click", (e) => {
  const b = e.target.closest("button"); if (!b) return;
  inspTab = b.dataset.t;
  $$("button", inspTabs).forEach((x) => x.classList.toggle("on", x === b));
  renderInspector();
});
function trackDiff(path, diffText) {
  const { a, d } = diffStats(diffText);
  const prev = fileChanges.get(path);
  fileChanges.set(path, { html: diffHtml(diffText), a: (prev ? prev.a : 0) + a, d: (prev ? prev.d : 0) + d });
  if (inspTab === "chg") renderInspector();
}
const _onToolDiff = onToolDiff;
onToolDiff = function (text) {
  const sm = curTool ? $(".sm", curTool) : null;
  if (sm) trackDiff(sm.textContent, text);
  _onToolDiff(text);
};
function renderInspector() {
  const body = $("#inspBody");
  if (inspTab === "chg") {
    if (!fileChanges.size) { body.innerHTML = `<div class="empty-i">Bu oturumda henüz dosya değişikliği yok.</div>`; return; }
    body.innerHTML = Array.from(fileChanges.entries()).map(([p, c], i) => `
      <div class="fchg" data-i="${i}">
        <button><svg class="i"><use href="#i-file"/></svg><span class="pth">${esc(p)}</span>${c.a ? `<span class="pa">+${c.a}</span>` : ""}${c.d ? `<span class="pd">-${c.d}</span>` : ""}</button>
        <div class="df"><div class="diff">${c.html}</div></div>
      </div>`).join("");
    $$(".fchg", body).forEach((f) => $("button", f).addEventListener("click", () => f.classList.toggle("open")));
  } else {
    renderInspectorSession();
  }
}
function renderInspectorSession() {
  if (inspTab !== "info") return;
  const body = $("#inspBody");
  if (!body) return;
  body.innerHTML = `<dl class="kv">
    <dt>Oturum</dt><dd>${esc(state.session || "—")}</dd>
    <dt>Klasör</dt><dd>${esc(state.cwd || "—")}</dd>
    <dt>Sağlayıcı</dt><dd>${esc(state.provider || "—")}</dd>
    <dt>Model</dt><dd>${esc(state.model || "—")}</dd>
    <dt>Mod</dt><dd>${state.mode === "plan" ? "Plan" : "Build"}</dd>
    <dt>Oto-onay</dt><dd>${state.autoApprove ? "Açık" : "Kapalı"}</dd>
    <dt>Değişen dosya</dt><dd>${fileChanges.size}</dd>
  </dl>`;
}

/* ========================================================================
   Klavye kısayolları
   ======================================================================== */

document.addEventListener("keydown", (e) => {
  const mod = e.ctrlKey || e.metaKey;
  if (mod && e.key.toLowerCase() === "n") { e.preventDefault(); $("#newBtn").click(); }
  else if (mod && e.key.toLowerCase() === "b") { e.preventDefault(); $("#sideBtn").click(); }
  else if (mod && e.key.toLowerCase() === "j") { e.preventDefault(); $("#inspBtn").click(); }
  else if (mod && e.key === ",") { e.preventDefault(); openSettings("provider"); }
  else if (mod && e.key.toLowerCase() === "k") { e.preventDefault(); openPalette(); }
});
$("#palBtn").addEventListener("click", openPalette);

/* ========================================================================
   Başlat
   ======================================================================== */

boot();
