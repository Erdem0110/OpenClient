@echo off
rem OpenClient'i masaustu uygulamasi olarak acar (konsol penceresi kapanabilir).
cd /d "%~dp0"
start "" pythonw "%~dp0OpenClient.pyw"
