# OpenClient

OpenCode/Claude Code tarzı yapay zekâ kodlama asistanı. **Sıfır bağımlılık** (yalnızca Python ≥ 3.9 standart kütüphanesi), Windows / macOS / Linux. İki şekilde kullanılır:

- **Masaüstü uygulaması** — kendi penceresinde açılan, modern bir arayüz (önerilen).
- **Terminal** — klasik komut satırı arayüzü.

İkisi de aynı çekirdeği (aynı ajan, aynı araçlar, aynı sağlayıcılar) kullanır; sadece önyüz farklıdır.

## Masaüstü uygulaması

```bash
cd openclient
python -m openclient.web            # proje klasörünü seçmen istenir
# veya doğrudan bir klasörle aç:
python -m openclient.web --cwd /proje/yolu
```

**Windows'ta çift tıkla çalıştırmak için:** `OpenClient.pyw` dosyasını masaüstüne kısayol olarak koy ve çift tıkla (konsol penceresi açmaz). `OpenClient.bat` da aynı işi yapar.

Kurulursa (`pip install -e .`) her yerden `openclient-app` komutuyla açılır.

Uygulama, bilgisayarında bulduğu Edge/Chrome/Brave'i "uygulama penceresi" (`--app=`) modunda açar; sekme çubuğu, adres çubuğu yoktur — gerçek bir masaüstü programı gibi görünür. Hiçbiri yoksa normal tarayıcı sekmesinde açılır. Arka planda yalnızca `127.0.0.1`'e bağlanan, rastgele bir jetonla korunan yerel bir sunucu çalışır; pencere kapanınca sunucu da kendini kapatır.

### Arayüz

- Sol panelde oturum geçmişi ve sağlayıcı/model durumu.
- Orta alanda sohbet: ajanın attığı her adım (araç çağrısı, diff, izin isteği) canlı bir "ray" üzerinde akar.
- Sağda, açılabilir "Denetçi" paneli: oturumdaki tüm dosya değişikliklerini (diff) ve oturum bilgisini gösterir.
- `/` yazınca komut menüsü, `@` yazınca dosya arama menüsü açılır.
- `Ctrl K` komut paleti, `Ctrl ,` ayarlar, `Ctrl B` / `Ctrl J` panelleri aç-kapat, `Tab` build/plan modu değiştirir.
- Koyu/açık tema ve yazı boyutu ayarlardan değiştirilebilir.

## Terminal

```bash
cd openclient
python -m openclient
```

İlk açılışta `/connect` yaz, sağlayıcıyı seç ve API anahtarını gir (gizli girilir, `~/.config/openclient/config.json` içine kaydedilir; Windows'ta `%APPDATA%\openclient`; bu ayar dosyası masaüstü uygulamasıyla ortaktır). Ortam değişkeni de olur: `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `OPENROUTER_API_KEY`.

```
openclient                       # etkileşimli mod
openclient "testleri düzelt"     # tek seferlik çalıştır
openclient -p ollama -m qwen3.5:4b --plan
openclient -c                    # son oturumu sürdür
```

## Kurulum (komut olarak)

```bash
cd openclient
pip install -e .
```

Bundan sonra her yerden `openclient` (terminal) ve `openclient-app` (masaüstü) komutları çalışır.

## Sağlayıcılar

| ad | not |
|---|---|
| `anthropic` | Claude (Messages API) |
| `openai` | OpenAI Chat Completions |
| `openrouter` | yüzlerce model |
| `ollama` | yerel modeller, anahtar gerekmez (`http://localhost:11434/v1`) |
| `custom` | herhangi bir OpenAI uyumlu sunucu (LM Studio, vLLM, llama.cpp …) |

Model listesi ayarlar penceresinde otomatik çekilir (API anahtarı girildiyse). Varsayılan model adları güncel olmayabilir, kontrol et.

## Komutlar

| komut | açıklama |
|---|---|
| `/connect` | API anahtarı gir / sağlayıcı seç (terminalde) |
| `/model`, `/models` | model göster-değiştir / sağlayıcıları listele |
| `/plan`, `/build` | salt-okunur plan modu / düzenleme+komut modu |
| `/init` | projeyi inceleyip `AGENTS.md` yazdır |
| `/compact` | bağlamı özetleyip küçült |
| `/new`, `/sessions`, `/resume <id>` | oturum yönetimi |
| `/yolo` | tüm izinleri otomatik onayla (dikkat) |
| `!komut` | kabukta doğrudan komut |

## Araçlar

`read`, `write`, `edit`, `bash`, `glob`, `grep`, `ls`, `webfetch`.
`write`, `edit` ve `bash` çalışmadan önce izin ister: bir kez, oturum boyunca veya reddet. Plan modunda bu araçlar tamamen kapalıdır.

Proje kuralları için çalışma dizininde (veya üstünde) `AGENTS.md` / `CLAUDE.md` bulunursa sistem istemine eklenir.

## Test

```bash
python -m unittest discover -s tests -v
```

## Proje yapısı

```
openclient/
  __init__.py, __main__.py   paket girişi (python -m openclient)
  agent.py                   ajan döngüsü: model ↔ araçlar ↔ izin
  frontend.py                ajanın konuştuğu arayüz sözleşmesi (terminal/web ortak)
  providers.py                Anthropic + OpenAI-uyumlu akış (streaming) istemcileri
  tools.py                    read/write/edit/bash/glob/grep/ls/webfetch
  config.py                   ayarlar, sağlayıcı ön ayarları, oturum kaydı
  ui.py, cli.py                terminal önyüzü
  web.py, web_ui/              masaüstü uygulaması: yerel sunucu + HTML/CSS/JS arayüz
OpenClient.pyw, OpenClient.bat  Windows çift-tık başlatıcılar
tests/                          testler + sahte (mock) LLM sunucusu
```
